package api4_String;

public class T20_Math {
  public static void main(String[] args) {
    int v1 = Math.abs(-10); //abs() : 절대값.
    double v2 = Math.abs(-3.14);
    System.out.println("v1 = " + v1);
    System.out.println("v2 = " + v2);
    System.out.println();
    
    double v3 = Math.ceil(3.14); //ceil() : 올림.
    double v4 = Math.ceil(-3.14);
    System.out.println("v3 = " + v3); // 결과는 4.0
    System.out.println("v4 = " + v4); // -3.14가 결과가 -3.0 인건 '올림' 한 것임.
    System.out.println();
    
    double v5 = Math.floor(5.3); // floor() : 버림.
    double v6 = Math.floor(-5.3);
    System.out.println("v5 = " + v5); // 결과는 5.0
    System.out.println("v6 = " + v6); // -5.3의 결과가 -6.0 인건 '버림' 한 것임.
    System.out.println();
    
    double v7 = Math.max(5.3, 6.5); // max() : 최대값.
    double v8 = Math.max(-5.3, -6.5);
    System.out.println("v7 = " + v7); // 결과는 6.5
    System.out.println("v8 = " + v8); // 결과는 -5.3
    System.out.println();
    
    double v9 = Math.min(5.3, 6.5); // min() : 최소값.
    double v10 = Math.min(-5.3, -6.5); 
    System.out.println("v9 = " + v9); // 결과는 5.3
    System.out.println("v10 = " + v10); // 결과는 -6.5
    System.out.println();
    
    double v11 = Math.random(); // random() : 0<= 실수형난수 <1
    System.out.println("v11 = " + v11); // 결과는 0.91860557924213
    System.out.println();
    
    int v12 = (int)(Math.random()*10) + 1; // 1~10까지의 정수형 난수
    System.out.println("v12 = " + v12); // 결과는 4
    System.out.println();
    
    double v13 = Math.rint(6.4); // rint() : 가장 가까운 정수형 실수값 출력.
    double v14 = Math.rint(-6.4); 
    System.out.println("v13 = " + v13); // 결과는 6.0
    System.out.println("v14 = " + v14); // 결과는 -6.0
    System.out.println();
    
    double v15 = Math.round(6.7); // round() : 반올림
    double v16 = Math.round(-6.7); 
    System.out.println("v15 = " + v15); // 결과는 7.0
    System.out.println("v16 = " + v16); // 결과는 -7.0
    System.out.println();
    
    // 소수점 2자리까지 구하시오(소수이하 3번째자리에서 반올림 하시오)
    double v17 = 12.3456;
    double v18 = 12.3456 * 100;
    double v19 = Math.round(v18);
    double v20 = v19 /100.0;
    System.out.println("v17 : " + v17);
    System.out.println("v18 : " + v18);
    System.out.println("v19 : " + v19);
    System.out.println("v20 : " + v20);
    
   
  }
}
