package api4_String;

public class T11_substring {
  public static void main(String[] args) {
               // 0         1
               // 012345678901
    String tel = "02-1234-5678";
    
    String str1 = tel.substring(0, tel.indexOf("-"));
    System.out.println("지역번호 = " + str1);
    
    String str2 = tel.substring(tel.indexOf("-")+1,tel.lastIndexOf("-"));
    System.out.println("국번 = " + str2);
    
    String str3 = tel.substring(tel.lastIndexOf("-")+1);
    System.out.println("전화번호 마지막 4번호 = " + str3);
  }
}
