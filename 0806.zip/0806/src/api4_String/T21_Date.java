package api4_String;

import java.text.SimpleDateFormat; //13번줄에서 ctrl + shift +알파벳 O 입력하면 나옴.
import java.util.Date;

public class T21_Date {
  public static void main(String[] args) {
    Date now = new Date(); //util package의 Date 클래스.
    System.out.println("now = " + now);
    String strNow = now.toString();
    System.out.println("strNow = " + strNow);
    
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월 dd일 hh시 mm분 ss초");
    String strSdf = sdf.format(now);
    System.out.println("now : " + strSdf);
  }
}
