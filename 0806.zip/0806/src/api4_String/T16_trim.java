package api4_String;

public class T16_trim {
  public static void main(String[] args) {
    String tel1 = "       02";
    String tel2 = "1234      ";
    String tel3 = "       5678       ";
    
    String telStr = tel1 + tel2 + tel3;
    System.out.println("telStr : " + telStr);
   
    String telStrTrim = tel1.trim() + tel2.trim() + tel3.trim();
    System.out.println(telStrTrim);
    System.out.println();
    
    // 정규식을 이용한 왼쪽/오른쪽 공백 제거하기
    System.out.println("tel1 : " + tel1);
    String tel1LTrim = tel1.replaceAll("^\\s+", ""); //("^\\s+" 앞의 모든 문자열(공백포함) 무시.) 공백을 무시하며 치환(replaceAll)해라.
    System.out.println("tel1 : " + tel1LTrim);
    
    System.out.println("tel2 + tel3 : " + (tel2+tel3));
    String tel1RTrim = tel2.replaceAll("\\s+$", ""); //("\\s+$" 뒤의 모든 문자열(공백포함) 무시.) 공백을 무시하며 치환(replaceAll)해라.
    String tel1Str = tel1RTrim + tel3;
    System.out.println("tel2 + tel3 : " + tel1Str);
  }
}
