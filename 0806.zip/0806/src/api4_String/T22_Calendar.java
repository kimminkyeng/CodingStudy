package api4_String;

import java.util.Calendar;
// Calendar는 추상클래스. 추상클래스는 new로 객체 생성을 못한다.
public class T22_Calendar {
  public static void main(String[] args) {
    Calendar now = Calendar.getInstance();
    int year = now.get(Calendar.YEAR);
    int month = now.get(Calendar.MONTH);
    int day = now.get(Calendar.DAY_OF_MONTH);
    
    int week = now.get(Calendar.DAY_OF_WEEK);
    String strWeek = null;
    switch(week) {
      case Calendar.MONDAY:
        strWeek = "월";
        break;
      case Calendar.TUESDAY:
        strWeek = "화";
        break;
      case Calendar.WEDNESDAY:
        strWeek = "수";
        break;
      case Calendar.THURSDAY:
        strWeek = "목";
        break;
      case Calendar.FRIDAY:
        strWeek = "금";
        break;
      case Calendar.SATURDAY:
        strWeek = "토";
        break;
      default:
        strWeek = "일";
    }
    
    int amPm = now.get(Calendar.AM_PM);
    String strAmPm = " ";
    if(amPm == Calendar.AM) {
      strAmPm = "오전";
    }
    else {
      strAmPm = "오후";
    }
    
    int hour = now.get(Calendar.HOUR);
    int minute = now.get(Calendar.MINUTE);
    int second = now.get(Calendar.SECOND);
    
    System.out.println(year+"년 "+month+"월 "+day+"일 "+strWeek+"요일");
    System.out.println(strAmPm+" "+hour+":"+minute+":"+second);
  }

}
