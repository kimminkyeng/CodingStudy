package api4_String;

public class T7_contains {
  public static void main(String[] args) {
    String str1 = "프로그램 : 자바 프로그래밍";
    // 문자열 자체가 동일해야됨. (동일하지 않으면 결과는 'false'로 나옴)
    boolean location1 = str1.contains("프로그래밍");
    System.out.println("'프로그래밍'의 위치는 : " + location1);
    
    boolean location2 = str1.contains("프로그래밍이란?");
    System.out.println("'프로그래밍이란?'의 위치는 : " + location2);
    
    boolean location3 = str1.contains("그");
    System.out.println("'그'의 위치는 : " + location3);
    
    boolean location4 = str1.contains("프로그래머");
    System.out.println("'프로그래머'의 위치는 : " + location4);
  }
}
