package api4_String;

public class T15_LowerUpper {
  public static void main(String[] args) {
    String str = "Java Programming";
    
    String strLow = str.toLowerCase();
    String strUpp = str.toUpperCase();
    System.out.println(str);
    System.out.println(strLow);
    System.out.println(strUpp);
    
    System.out.println(strLow.equals(strUpp)); //값이 틀리기 때문에 결과가 false로 나옴.
    System.out.println(strLow.equalsIgnoreCase(strUpp));  //대소문자 무시하고 비교. 결과는 true로 나옴.
  }
}
