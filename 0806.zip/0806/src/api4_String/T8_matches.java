package api4_String;

public class T8_matches {
  public static void main(String[] args) {
    String str1 = "1.프로그램 : 자바(Java) 프로그래밍";
    
    // 특정문자열 검색
    if(str1.matches(".*자바.*")) {//str1.matches(regex) 중 regex는 정규식이며 예약어이다. '.*.*'은 SQL의 '%'와 같다.
      System.out.println("'자바' 문자열이 포함되어 있습니다.");
    }
    else {
      System.out.println("'자바' 문자열이 포함되어 있지 않습니다.");
    }
    
    // 영문자가 포함되어있는지?
    if(str1.matches(".*[a-zA-Z].*")) {//str1.matches(regex) 중 regex는 정규식이며 예약어이다. '.*.*'은 SQL의 '%'와 같다. 정규식은 특정 범위 지정 없을시 항상 []가 들어감.
      System.out.println("영문자가 포함되어 있습니다.");
    }
    else {
      System.out.println("영문자가 포함되어 있지 않습니다.");
    }
    
    //숫자를 포함하고 있는지 검색하세요.
    if(str1.matches(".*[0-9].*")) {//str1.matches(regex) 중 regex는 정규식이며 예약어이다. '.*.*'은 SQL의 '%'와 같다. 정규식은 특정 범위 지정 없을시 항상 []가 들어감.
      System.out.println("숫자가 포함되어 있습니다.");
    }
    else {
      System.out.println("숫자가 포함되어 있지 않습니다.");
    }
    
    //한글을 포함하고 있는지 검색하세요.
    if(str1.matches(".*[가-힣].*")) {//str1.matches(regex) 중 regex는 정규식이며 예약어이다. '.*.*'은 SQL의 '%'와 같다. 정규식은 특정 범위 지정 없을시 항상 []가 들어감.
      System.out.println("한글이 포함되어 있습니다.");
    }
    else {
      System.out.println("한글이 포함되어 있지 않습니다.");
    } 
  }
}
