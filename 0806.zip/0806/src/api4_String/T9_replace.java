package api4_String;

public class T9_replace {
  public static void main(String[] args) {
    String oldStr = "자바 프로그래밍";
    String newStr = oldStr.replace("자바", "JAVA");
    
    System.out.println("newStr : " + newStr);
    System.out.println("oldStr : " + oldStr);
  }
}
