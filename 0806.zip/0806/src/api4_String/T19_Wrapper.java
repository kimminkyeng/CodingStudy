package api4_String;

public class T19_Wrapper {
  public static void main(String[] args) {
    //자동박싱
    // Integer obj1 = new Integer(100); 이렇게 하면 복잡함.
    Integer obj1 = 100; //위에 주석처리 되어있는것과 같음. 간편한 방법.
    // Integer obj2 = "100"; "100" 는 문자열이라 박싱이 안됨. String으로 선언해야함.
    
    System.out.println("obj1 : " + obj1);
    
    //자동 언박싱
    int var1 = obj1; //Wrapper 객체인데 정수형이라 에러가 안남.
    System.out.println("var1 : " + var1);
    
    System.out.println(obj1 == var1); //결과는 true. obj1를 값으로 처리했다는 뜻.
    System.out.println(obj1.equals(var1)); //위 15번줄과 같은 결과.
    
    //연산후 자동 언박싱
    int result = obj1 + var1;
    System.out.println("result : " + result); //결과는 200.
    
    //-128~127값의 범위만 == , != 비교 가능. 그외 범위는 불가능.
    // 그러므로 박싱된 값을 비교하려면 .equals() 사용. (=그외의 범위는 무조건 .equals() 메소드로 비교할 것.)
    Integer obj2 = 300;
    Integer obj3 = 300;
    System.out.println("obj2 == obj3 ?" + (obj2 == obj3)); //결과는 false. (-128~127값의 범위가 아니기 때문)
    System.out.println("obj2.equals(obj3)?" + (obj2.equals(obj3)));//결과는 true.
  }
}
