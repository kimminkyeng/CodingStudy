package api4_String;

public class T13_split {
  public static void main(String[] args) {
               // 0         1
               // 012345678901
    String tel = "02-1234-5678";
    
    String[] telArr = tel.split("-");
    
    for(int i=0; i<telArr.length; i++) {
      System.out.println(i+"번째 : " + telArr[i]);
    }
    
    System.out.println();
    
    //향상된 for문(이걸 많이 사용함)
    int cnt = 0;
    for(String tItem : telArr) {
      System.out.println(cnt+"번째 : " + tItem);
      cnt++;
    }
  }
}
