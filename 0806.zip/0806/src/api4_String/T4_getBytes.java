package api4_String;

import java.io.UnsupportedEncodingException;

public class T4_getBytes {
  public static void main(String[] args) {
    String str = "안녕하세요"; //한글자당 길이가 3. 결과는 15.
    
    byte[] bytes1 = str.getBytes(); //UTF-8 방식.
    System.out.println("byte1의 길이 : " + bytes1.length);
    
    String str1 = new String(bytes1);
    System.out.println("str1:"+str1); //결과는 다시 "안녕하세요" 로 출력됨.
    System.out.println();
    
    try {
      //EUC-KR로 인코딩과 디코딩 하는 과정. (윈도우는 EUC-KR을 취급함)
      byte[] bytes2 = str.getBytes("EUC-KR"); //EUC-KR로 예외처리하여 인코딩함.
      System.out.println("bytes2 : " + bytes2);
      String str2 = new String(bytes2,"EUC-KR"); // EUC-KR로 디코딩 완료. 결과는 "안녕하세요"로 출력됨.
      System.out.println("str2 : " + str2);//결과가 특수문자로 나옴.EUC-KR로 다시 디코딩해야됨.
      System.out.println();

      //다시 UTF-8로 인코딩과 디코딩 하는 과정.
      byte[] bytes3 = str.getBytes("UTF-8"); //UTF-8로 예외처리하여 인코딩함.
      System.out.println("bytes3 : " + bytes3);
      String str3 = new String(bytes3,"UTF-8"); // UTF-8로 디코딩 완료. 결과는 "안녕하세요"로 출력됨.
      System.out.println("str3 : " + str3);//결과가 특수문자로 나옴.EUC-KR로 다시 디코딩해야됨.
      System.out.println();
    } catch (UnsupportedEncodingException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    
    
  }
}
