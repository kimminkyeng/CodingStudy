package api4_String;

import java.util.Scanner;

// 파일명을 입력받아, 확장자가 jpg, gif, png, zip파일만 업로드 처리하시오.
public class T12_substring {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    String img;
    
    System.out.println("파일명을 입력하세요");
    img = sc.next();
    
    String imgExt = img.substring(img.lastIndexOf(".")+1);
    
    if(imgExt.equals("jpg") || imgExt.equals("gif") || imgExt.equals("png") || imgExt.equals("zip")){
      System.out.println("파일이 업로드 되었습니다.");
    }
    else {
      System.out.println("업로드 가능한 파일이 아닙니다.");
    }
    sc.close();
  }
}
