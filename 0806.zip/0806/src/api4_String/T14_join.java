package api4_String;

public class T14_join {
  public static void main(String[] args) {
               // 0         1
               // 012345678901
    String tel = "02-1234-5678";
    System.out.println("tel : " + tel);
    
    String[] telArr = tel.split("-");
    
    for(int i=0; i<telArr.length; i++) {
      System.out.println(i+"번째 : " + telArr[i]);
    }
    
    String telJoin = String.join("*", telArr);
    System.out.println("telJoin : " + telJoin);
    
    String telJoin2 = String.join("-", telArr);
    System.out.println("telJoin2 : " + telJoin2);
  }
}
