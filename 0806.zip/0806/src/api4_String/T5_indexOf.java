package api4_String;

public class T5_indexOf {
  public static void main(String[] args) {
    String str1 = "자바 프로그래밍";
    // 문자열 자체가 동일해야됨. (동일하지 않으면 결과는 '-1'로 나옴)
    int location1 = str1.indexOf("프로그래밍");
    System.out.println("'프로그래밍'의 위치는 : " + location1);
    
    int location2 = str1.indexOf("프로그래밍이란?");
    System.out.println("'프로그래밍이란?'의 위치는 : " + location2);
    
    int location3 = str1.indexOf("그");
    System.out.println("'그'의 위치는 : " + location3);
    
    int location4 = str1.indexOf("프로그래머");
    System.out.println("'프로그래머'의 위치는 : " + location4);
  }
}
