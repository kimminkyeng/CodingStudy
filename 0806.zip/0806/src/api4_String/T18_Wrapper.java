package api4_String;

public class T18_Wrapper {
  public static void main(String[] args) {
   //박싱 (객체를 박싱)
   Integer obj1 = new Integer(100);
   Integer obj2 = new Integer("200"); // 'Integer'라 200을 "200"으로 작성해도 숫자로 간주해버림.
   Integer obj3 = Integer.valueOf("100");
   
   System.out.println("obj1 = " + obj1);
   System.out.println("obj2 = " + obj2);
   System.out.println("obj3 = " + obj3);
   System.out.println();
   
   //언박싱 (객체를 언박싱)
   int var1 = obj1.intValue();
   int var2 = obj2.intValue();
   int var3 = obj3.intValue();
   
   System.out.println("var1 = " + var1);
   System.out.println("var2 = " + var2);
   System.out.println("var3 = " + var3);
  }
}
