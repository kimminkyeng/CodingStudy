package api4_String;

public class T17_valueOf {
  public static void main(String[] args) {
    String str1 = String.valueOf(123);
    String str2 = String.valueOf(12.34);
    String str3 = String.valueOf(true);
    
    System.out.println(str1);
    System.out.println(str3);
    System.out.println(str2);
    
    int su1 = 100;
    int su2 = 200;
    
    System.out.println(su1+su2);
    
    String su2Str = String.valueOf(su2);
    System.out.println(su1 + su2Str); // 'su2Str' 가 문자(String)로 바뀌어서 결과가 '100200' 으로 숫자가 붙어서 나옴.
    
  }
}
