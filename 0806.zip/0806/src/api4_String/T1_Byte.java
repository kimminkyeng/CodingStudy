package api4_String;

public class T1_Byte {
  public static void main(String[] args) {
    // A는 65번 a는 97번
    //6    7         8         9         1         11        12
    //5678901234567890123456789012345678901234567890123456789012
    //ABCDEFGHIJKLMNOPQRSTUVWXYZ      abcdefghijklmnopqrstuvwxyz
    byte[] bytes = {74,97,118,97,13,10,84,101,115,116};
    
    String str1 = new String(bytes);
    System.out.println("str1="+str1);
    
    String str2 = new String(bytes,6,4);
    System.out.println("str2="+str2);
  }
}
