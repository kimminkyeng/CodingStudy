package api4_String;

public class T10_substring {
  public static void main(String[] args) {
               // 0         1
               // 01234567890123
    String ssn = "123456-1234567";
    
    String str1 = ssn.substring(0,6);
    System.out.println("str1 = " + str1);
    
    String str2 = ssn.substring(7);
    System.out.println("str2 = " + str2);
    
    String str3 = ssn.substring(7, 14);
    System.out.println("str3 = " + str3);
    
    String str4 = ssn.substring(7, ssn.length());
    System.out.println("str4 = " + str4);
  }
}
