package api4_String;

import java.io.IOException;

public class T2_Byte {
  public static void main(String[] args) throws IOException {
    byte[] bytes = new byte[100];
    
    System.out.print("입력하세요");
    int acceptByte = System.in.read(bytes); //사용자가 문자 입력 후, 컴퓨터에서 정수타입으로 변경하여(바이트 배열로 묶어서) 입력받은 후 다시 문자로 출력.
    
    String str = new String(bytes);
    System.out.println("입력된 문자는?" + str);
  }
}
