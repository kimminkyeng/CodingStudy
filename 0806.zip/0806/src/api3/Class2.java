package api3;
// Class1 실행클래스
public class Class2 {
  public static void main(String[] args) {
    Class clazz1 = Class1.class; //Class1 클래스 객체를 실행
    Class clazz2 = null; // 전역변수라서 try catch 안에있는걸 밖으로 옮겨야함.
    
    try {
      clazz2 = Class.forName("api3.Class1");
    } catch (ClassNotFoundException e) { //절대경로를 찾을때 'e'를 씀.
      e.printStackTrace();
    }
    Class1 class1 = new Class1();
    Class clazz3 = class1.getClass();
    
    // 결과가 같은지 아닌지 확인하기
    System.out.println("clazz1="+ clazz1.getName()); //실행결과 : 패키지명.클래스명
    System.out.println("clazz1="+ clazz1.getSimpleName()); //실행결과 : 클래스명
    System.out.println("clazz1="+ clazz1.getPackage().getName()); //실행결과 : 패키지명
    System.out.println();
    
    System.out.println("clazz2="+ clazz2.getName());
    System.out.println("clazz2="+ clazz2.getSimpleName());
    System.out.println("clazz2="+ clazz2.getPackage().getName());
    System.out.println();
    
    System.out.println("clazz3="+ clazz3.getName());
    System.out.println("clazz3="+ clazz3.getSimpleName());
    System.out.println("clazz3="+ clazz3.getPackage().getName());
    System.out.println();
  }
}
