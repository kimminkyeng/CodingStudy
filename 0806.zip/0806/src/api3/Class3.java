package api3;

public class Class3 {
  public static void main(String[] args) {
    Class clazz1 = Class1.class;
    
    String path0 = clazz1.getResource("22.jpg").getPath(); //실행결과 : path0=/D:/java2006/java/works/0806/bin/api3/22.jpg
    String path2 = clazz1.getResource("images/11.jpg").getPath(); //실행결과 : path2=/D:/java2006/java/works/0806/bin/api3/images/11.jpg
    
    System.out.println("path0="+path0);
    System.out.println("path2="+path2);
  }
}
