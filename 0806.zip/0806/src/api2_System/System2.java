package api2_System;
//현재시각읽기
public class System2 {
  public static void main(String[] args) {
    long time1 = System.nanoTime(); //현재 시작시간을 읽는다.
    
    int sum=0;
    for (int i=1; i<1000000; i++) {
      sum +=i;
    }
    
    long time2 = System.nanoTime(); //현재 작업끝시간을 읽는다.
    
    System.out.println("1~1000000의 합은? " +sum);
    System.out.println("계산에 소모된 시간은? " + (time2 - time1));
  }
}
