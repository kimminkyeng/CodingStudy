package api1;

public class Object4 {
  private String name;
  private int age;
  public Object4(String name, int age) {
    this.name = name;
    this.age = age;
  }
  @Override
  public String toString() { //문자로 오버라이딩 처리
    return name + " , " + age;
  }
  
  
  
}
