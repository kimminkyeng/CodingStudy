package api1;

public class Object2 {
  public String product;
  
  public Object2(String product) {
    this.product = product;
  }

  @Override
  public boolean equals(Object obj) {
    if(obj instanceof Object2) {
      Object2 obj2 = (Object2) obj;
      if(product.contentEquals(obj2.product)) {
        return true;
      }
    }
    return false;
  }
}
