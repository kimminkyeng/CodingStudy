package api1;
// Database에 넣을 클라이언트가 요청한 Jsp 자료가 어디 어디에 찍히는지(흘렸는지) 알아보기 위해서 쓰는 방법. (jsp에서 database까지 가는 여정)
public class ObjVoRun {
  public static void main(String[] args) {
    ObjVo vo = new ObjVo("홍길동" ,22, 'm');
    
    System.out.println(vo.toString());
  }
}
