package api1;

public class Object5 {
  private String name;
  private int age;
  public Object5(String name, int age) {
    this.name = name;
    this.age = age;
  }
  @Override
  public String toString() {
    return "Object5 [name=" +name+",age="+age+"]";
  }
  
  
}
