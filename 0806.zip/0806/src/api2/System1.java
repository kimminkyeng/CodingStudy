package api2;
// JVM 종료 연습(System.exit(0);)
public class System1 {
  public static void main(String[] args) {
    int tot=0;
    int i;
    System.out.println("자바 종료연습");
    for(i=0;i<=10;i++) {
      tot +=i;
      if(i==5) {
        System.exit(0);
        //break;
      }
    }
    System.out.println("1~"+i+"까지의 합은?"+tot);
  }
}
