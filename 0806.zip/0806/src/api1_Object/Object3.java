package api1_Object;

import java.util.Date;

public class Object3 {
  public static void main(String[] args) {
    Object obj = new Object();
    
    System.out.println("obj = " + obj.toString()); // 16진수 주소로나옴.(obj = java.lang.Object@15db9742)
    
    Date obj2 = new Date();
    System.out.println("obj2 = " + obj2.toString()); // 결과가 현재날짜로 나오는 이유가 저절로 Date 객체 안에서 오버라이드(재정의) 처리됨.(obj2 = Thu Aug 06 20:01:55 KST 2020)
  }
}
