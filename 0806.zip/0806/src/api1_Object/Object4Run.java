package api1_Object;

public class Object4Run {
  public static void main(String[] args) {
    Object4 obj = new Object4("홍길동", 25);
    
    System.out.println("성명 , 나이 : " + obj.toString()); // 오버라이딩 전에 결과가 (성명 , 나이 : api1.Object4@15db9742)로 나옴. 오버라이딩 후 결과가 (성명 , 나이 : 홍길동 , 25)<- 이렇게 나옴.
  }
}
