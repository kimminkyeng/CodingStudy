package api1_Object;

public class Object2Run {
  public static void main(String[] args) {
   Object2 obj1 = new Object2("냉장고");
   Object2 obj2 = new Object2("냉장고");
   Object2 obj3 = new Object2("선풍기");
   
   if(obj1 ==  obj2)
   {System.out.println("1.obj1과 obj2는 동등 합니다.");
     }
   else {
     System.out.println("1.obj1과 obj2는 동등 하지 않습니다.");
   }
   System.out.println();
   if(obj1.equals(obj2))
   {System.out.println("2.obj1과 obj2는 동등 합니다.");
     }
   else {
     System.out.println("2.obj1과 obj2는 동등 하지 않습니다.");
   }
   System.out.println();
   if(obj1.equals(obj3))
   {System.out.println("3.obj1과 obj3는 동등 합니다.");
     }
   else {
     System.out.println("3.obj1과 obj3는 동등 하지 않습니다.");
   }
  }
}
