package api1_Object;

public class Object1 {
  public String product;
  
  public Object1(String product) {
    this.product = product;
  }

}
