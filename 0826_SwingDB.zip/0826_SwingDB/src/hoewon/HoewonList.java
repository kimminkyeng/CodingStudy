package hoewon;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;

// 회원 전체 조회 클래스
public class HoewonList extends JFrame {
  Vector vData, headings;
  JPanel pnTop;
  DefaultTableModel defaultTableModel;
  JTable jTable;
  JScrollPane jScrollPane;
  JButton btnExit;
  
  //String[] headings = {"고유번호","성명","나이"};
  
  HoewonDao dao = new HoewonDao();
  private JTextField txtSearch;
  
  public HoewonList() {
    super("회원 전체 조회");
    setSize(600, 600/4*3);
    setLocationRelativeTo(null);
    getContentPane().setLayout(null);
    
    //프레임 상단(북쪽)레이아웃
    pnTop = new JPanel();
    pnTop.setBounds(0, 0, 584, 46);
    pnTop.setLayout(null);
    btnExit = new JButton("종 료");
    btnExit.setBounds(490, 10, 82, 23);
    pnTop.add(btnExit);
    
    getContentPane().add(pnTop);
    
    JComboBox comboBox = new JComboBox();
    comboBox.setModel(new DefaultComboBoxModel(new String[] {"고유번호", "성명", "나이"}));
    comboBox.setBounds(28, 11, 94, 21);
    pnTop.add(comboBox);
    
    txtSearch = new JTextField();
    txtSearch.setBounds(131, 11, 116, 21);
    pnTop.add(txtSearch);
    txtSearch.setColumns(10);
    
    JButton btnSearch = new JButton("조건검색");
    btnSearch.setBounds(259, 10, 97, 23);
    pnTop.add(btnSearch);
    
    JButton btnList = new JButton("전체검색");
    btnList.setBounds(381, 10, 97, 23);
    pnTop.add(btnList);
    
    // DB에서 회원리스트를 가져온다.
    vData = dao.getList();
    
    // heading 머릿글 생성
    
    headings = getHeadings();
    
    // 프레임 중앙(center) 레이아웃 디자인
    defaultTableModel = new DefaultTableModel(vData, headings);
    jTable = new JTable(defaultTableModel);
    jScrollPane = new JScrollPane(jTable);
    jScrollPane.setBounds(0, 45, 584, 366);
    //jScrollPane.add(jTable);
    
    getContentPane().add(jScrollPane);
    
    
    
    setVisible(true);
    //전체검색
    btnList.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        dispose();
        new HoewonList();
      }
    });
    
    //조건검색
    btnSearch.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        String strSearch = txtSearch.getText();
        String comboStr = (String) comboBox.getSelectedItem();
        
        if(strSearch.equals("")) {
          JOptionPane.showMessageDialog(null, "검색어를 입력하세요");
          txtSearch.requestFocus();
        }
        else { //정상적으로 콤보상자의 필드의 자료가 입력되어 있을경우 수행되는 부분.
          //System.out.println("콤보박스에 선택된 내용은: " + comboStr);
          if(comboStr.equals("고유번호")) {
            vData = dao.getSearch("idx",strSearch);
          }
          else if(comboStr.equals("성명")) {
            vData = dao.getSearch("name",strSearch);
          }
          else {
            vData = dao.getSearch("age",strSearch);
          }
          //System.out.println("vData=" + vData);
          defaultTableModel.setDataVector(vData, headings);
        }
      }
    });
    
    //종료
    btnExit.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        // System.exit(0); 현재 창의 모든것을 종료시켜버림.
        dispose(); // 자신의 창만을 닫아준다.
      }
    });
    
  }
  
  private Vector getHeadings() {
    Vector heading = new Vector();
    heading.add("고유번호");
    heading.add("성명");
    heading.add("나이");
    
    return heading;
  }

  public static void main(String[] args) {
    new HoewonList();
  }
}
