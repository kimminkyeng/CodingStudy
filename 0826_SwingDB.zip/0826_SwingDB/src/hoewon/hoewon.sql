show tables;

create table hoewon2(
  idx int not null auto_increment,
  name varchar(20) not null,
  age int default 20,
  primary key(idx)
);

insert into hoewon2 values (default, '홍길동',25);
insert into hoewon2 values (default, '김말숙',29);
insert into hoewon2 values (default, '이기자',32);
insert into hoewon2 values (default, '강감찬',35);
insert into hoewon2 values (default, '오사랑',default);

select * from hoewon2;