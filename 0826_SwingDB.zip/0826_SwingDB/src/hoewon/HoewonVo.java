package hoewon;

public class HoewonVo { //private 작성후, source 메뉴에서 getters and setters 선택해서 생성후, toString 재선택 후 생성.
  private int idx;
  private String name;
  private int age;
  
  public HoewonVo() {}


  public int getIdx() {
    return idx;
  }

  public void setIdx(int idx) {
    this.idx = idx;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public int getAge() {
    return age;
  }

  public void setAge(int age) {
    this.age = age;
  }
  
  @Override
  public String toString() {
    return "HoewonVo [idx=" + idx + ", name=" + name + ", age=" + age + "]";
  }
}
