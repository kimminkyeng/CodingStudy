package hoewon;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class HoewonDao {
  Vector vData;
  
  Connection conn = null;
  PreparedStatement pstmt = null;
  ResultSet rs = null;
  
  String sql = "";
  private String url = "jdbc:mysql://localhost:3306/javadb";
  private String user = "root";
  private String password = "1234";
    
 
  
  public HoewonDao() {
    try {
      Class.forName("com.mysql.jdbc.Driver");
      conn = DriverManager.getConnection(url, user, password); //다 입력후, add catch 클릭!
    } catch (ClassNotFoundException e) {
      System.out.println("드라이버 검색실패!");
    } //제작사측에서 제공하는 드라이브명을 그대로 써야함.
      catch (SQLException e) {
      System.out.println("DB연동 실패" + e.getMessage());
    }
  }
  
  public void dbClose() {
    try {
      conn.close();
    } catch (SQLException e) {}
  }

  public Vector getList() {
    vData = new Vector();
    
    try {
      sql = "select * from hoewon2 order by name";
      pstmt = conn.prepareStatement(sql);
      rs = pstmt.executeQuery();
      
      while(rs.next()) {
        Vector vo = new Vector();
        
        vo.add(rs.getInt("idx"));
        vo.add(rs.getString("name"));
        vo.add(rs.getInt("age"));
        
        vData.add(vo);
      }
    } catch (SQLException e) {
      System.out.println("SQL 오류" + e.getMessage());
    }
     finally {
       try {
        if(rs != null || !rs.isClosed()) rs.close();
        if(pstmt != null || !pstmt.isClosed()) pstmt.close();
      } catch (SQLException e) {
     }
    }
    return vData;
  }

  public Vector getSearch(String gubun, String strSearch) {
    vData = new Vector();
    try {
      if(gubun.equals("idx")) {
        sql = "select * from hoewon2 where idx=?";
      }
      else if (gubun.equals("name")) {
        sql = "select * from hoewon2 where name=?";
      }
      else {
        sql = "select * from hoewon2 where age=? order by age";
      }
      pstmt = conn.prepareStatement(sql);
      pstmt.setString(1, strSearch);
      rs = pstmt.executeQuery();
      while(rs.next()) {
        Vector vo = new Vector();
        
        vo.add(rs.getInt("idx"));
        vo.add(rs.getString("name"));
        vo.add(rs.getInt("age"));
        
        vData.add(vo);
      }
    } catch (SQLException e) {
      System.out.println("SQL 에러 : " + e.getMessage());
    }
    return vData;
  }
  
}
