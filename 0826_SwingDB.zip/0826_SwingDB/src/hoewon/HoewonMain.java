package hoewon;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.ActionEvent;

public class HoewonMain extends JFrame {
  
  public HoewonMain() {
    super("회원 메인 프로그램");
    setSize(600, 600/4*3); //4대 3 비율
    setLocationRelativeTo(null);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    getContentPane().setLayout(null);
    
    JLabel lblNewLabel = new JLabel("회원관리 메인 화면");
    lblNewLabel.setBounds(127, 45, 298, 57);
    lblNewLabel.setFont(new Font("굴림", Font.BOLD, 20));
    lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
    getContentPane().add(lblNewLabel);
    
    JButton btnList = new JButton("회원전체조회");
    btnList.setBounds(201, 323, 164, 46);
    btnList.setFont(new Font("굴림", Font.BOLD, 18));
    getContentPane().add(btnList);
    
    JButton btnExit = new JButton("종료");
    btnExit.setBounds(395, 320, 164, 46);
    btnExit.setFont(new Font("굴림", Font.BOLD, 18));
    getContentPane().add(btnExit);
    
    JButton btnDelete = new JButton("삭제");
    btnDelete.setFont(new Font("굴림", Font.BOLD, 18));
    btnDelete.setBounds(12, 323, 148, 46);
    getContentPane().add(btnDelete);
    
    setVisible(true);
    
    // 삭제버튼 메소드
    btnDelete.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
      }
    });
    
    // 종료버튼 메소드(마우스로만 종료)
    btnExit.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        JOptionPane.showMessageDialog(null, "작업종료");
        System.exit(0);
      }
    });
    
    // 종료버튼 메소드(키보드 엔터키로도 종료)
    btnExit.addKeyListener(new KeyAdapter() {
      @Override
      public void keyPressed(KeyEvent e) {
        System.exit(0);
      } 
    });
    
    
    // 회원전체조회버튼 메소드
    btnList.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        new HoewonList();
      }
    });
  }
  
  public static void main(String[] args) {
    new HoewonMain();
  }
}
