show tables;

create table exam (
  idx  int  not null  auto_increment primary key, /* 고유번호 */
  mid  varchar(20) not null,    /* 아이디 */
  pwd  varchar(20) not null,    /* 비밀번호 */
  name varchar(20) not null     /* 성명 */
);

desc exam;

insert into exam values (default,'hkd1234','1234','홍길동');
insert into exam values (default,'kms1234','1234','김말숙');
insert into exam values (default,'222','222','연습자료');

select * from exam;
select * from exam where name='홍길순';
select * from exam where name like '%나무%';

delete from exam where name='';
