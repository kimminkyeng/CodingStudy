package Hoewon5;

public class HoewonVo {
  private int idx;
  private String mid;
  private String pwd;
  private String name;
  
  public HoewonVo() {}

  public int getIdx() {
    return idx;
  }
  public void setIdx(int idx) {
    this.idx = idx;
  }
  public String getMid() {
    return mid;
  }
  public void setMid(String mid) {
    this.mid = mid;
  }
  public String getPwd() {
    return pwd;
  }
  public void setPwd(String pwd) {
    this.pwd = pwd;
  }
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  @Override
  public String toString() {
    return "HoewonVo [idx=" + idx + ", mid=" + mid + ", pwd=" + pwd + ", name=" + name + "]";
  }
}
