package Hoewon5;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

public class HoewonMenu extends JFrame {
  HoewonDao dao = new HoewonDao();
  private JButton btnUpdate, btnList, btnExit;

  public static void main(String[] args) {
    EventQueue.invokeLater(new Runnable() {
      public void run() {
        try {
          HoewonMenu window = new HoewonMenu();
          window.setVisible(true);
        } catch (Exception e) {
          e.printStackTrace();
        }
      }
    });
  }

  public HoewonMenu() {
    initialize();  // 화면디자인
  }

  private void initialize() {
    setTitle(" 회원관리(v5.0)");
    setBounds(100, 100, 550, 400);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLocationRelativeTo(null);
    getContentPane().setLayout(null);
    
    JLabel lblNewLabel = new JLabel("회 원 관 리 프 로 그 램(v5.0)");
    lblNewLabel.setFont(new Font("굴림", Font.BOLD, 24));
    lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
    lblNewLabel.setBounds(72, 46, 382, 51);
    getContentPane().add(lblNewLabel);
    
    btnUpdate = new JButton("회원정보수정");
    btnUpdate.setFont(new Font("굴림", Font.PLAIN, 16));
    btnUpdate.setBounds(58, 267, 140, 40);
    getContentPane().add(btnUpdate);
    
    btnList = new JButton("전체조회");
    btnList.setFont(new Font("굴림", Font.PLAIN, 16));
    btnList.setBounds(235, 267, 100, 40);
    getContentPane().add(btnList);
    
    btnExit = new JButton("종  료");
    btnExit.setFont(new Font("굴림", Font.PLAIN, 16));
    btnExit.setBounds(374, 267, 100, 40);
    getContentPane().add(btnExit);
    
    setVisible(true);
    
    // 버튼감시 리스너
    // 회원수정
    btnUpdate.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        String mid = JOptionPane.showInputDialog("수정할 회원의 아이디를 입력하세요");
        HoewonVo vo = dao.search(mid);
        if(vo == null) {
          JOptionPane.showMessageDialog(null, "회원 아이디가 틀립니다. 확인해 주세요!");
        }
        else {
          new HoewonUpdate(vo);
        }
      }
    });
    
    // 회원전체조회
    btnList.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        new HoewonList();
      }
    });
    
    // 종료버튼
    btnExit.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(null, "작업종료!\n수고하셨습니다.");
        System.exit(0);
      }
    });
  }
}