package Hoewon5;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class HoewonList extends JFrame implements ActionListener {
  private HoewonDao dao = new HoewonDao();
  private Vector vData;  // 전체 레코드
  private Vector cols;   // 필드명
  private DefaultTableModel model;
  private JTable jTable;
  private JScrollPane jspan;
  private JPanel jpan1;
  private JButton btnSearch, btnList, btnDelete, btnExit;
  private JTextField txtSearch;
  private JComboBox<String> combo;
  private String[] items = {"고유번호","아이디","성명"};

  public HoewonList() {
    initialize("allList", 0); // 매개변수(값) '0'은 처음 디자인폼을 로드한다고 알림.
  }
  
  // 리스트 출력폼 디자인
  private void initialize(String gubun, int sw) {
    setSize(500, 300);
    setLayout(new BorderLayout());
    //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLocationRelativeTo(null);
    
    if(gubun.equals("allList")) {  // 전체검색처리요청
      allList();
    }
    else if(gubun.equals("search")) {  // 조건검색처리 요청
      search();
    }
    
    cols = getColumn(); // 필드명 검색처리
    
    if(sw == 0) {// 처음 호출때만 DefaultTableModel객체를 생성한다.
      model = new DefaultTableModel(vData, cols);
    }
    else {
      model.setDataVector(vData, cols);
    }
    
    // 변경된 값을 테이블에 반영시킨다.
    jTable = new JTable(model);
    jspan = new JScrollPane(jTable);
    add(jspan, BorderLayout.CENTER);
    
    if(sw == 0) { // 처음 호출때는 각종 컴포넌트 디자인들을 생성하고, 이후는 기존것들을 사용해야함(꼭!!!)
      jpan1 = new JPanel();
      
      txtSearch = new JTextField(7);
      combo = new JComboBox(items);
      
      btnSearch = new JButton("조건검색");
      btnList = new JButton("전체검색");
      btnDelete = new JButton("삭제");
      btnExit = new JButton("종료");
      
      jpan1.add(combo);
      jpan1.add(txtSearch);
      jpan1.add(btnSearch);
      jpan1.add(btnList);
      jpan1.add(btnDelete);
      jpan1.add(btnExit);
      add(jpan1, BorderLayout.NORTH);
      
      setVisible(true);
      
      // 감시 리스너 처리
      btnSearch.addActionListener(this);
      btnList.addActionListener(this);
      btnDelete.addActionListener(this);
      btnExit.addActionListener(this);
      
      addWindowListener(new WindowAdapter() {
        public void windowClosing(WindowEvent e) {
          dispose();
        }
      });
    }
  }

  // 조건검색
  private void search() {
    String field = (String) combo.getSelectedItem(); // 콤보상자의 선택내용 받아오기
    String word = txtSearch.getText();
    
    if(field.equals("고유번호")) {
      vData = dao.search("idx", word);
    }
    else if(field.equals("아이디")) {
      vData = dao.search("mid", word);
    }
    else {
      vData = dao.search("name", word);
    }
  }

  // 전체검색(처음로딩시에도 처리하고, '전체검색'버튼 클릭시도 처리한다.
  private void allList() {
    vData = dao.getHoewonList();
  }

  // 필드명 처리
  private Vector getColumn() {
    Vector colName = new Vector();
    colName.add("고유번호");
    colName.add("아이디");
    colName.add("비밀번호");
    colName.add("성명");
    
    return colName;
  }

  public static void main(String[] args) {
    new HoewonList();
  }

  @Override
  public void actionPerformed(ActionEvent e) {
    Object res = e.getSource();
    if(res == btnSearch) {  // 조건검색처리
      if(txtSearch.getText().equals("")) {
        JOptionPane.showMessageDialog(null, "검색어를 입력하세요!");
        txtSearch.requestFocus();
      }
      else {
        initialize("search", 1);
      }
    }
    else if(res == btnList) {  // 전체검색처리
      initialize("allList", 1);
    }
    else if(res == btnDelete) { // 삭제처리
      if(txtSearch.getText().equals("")) {
        JOptionPane.showMessageDialog(null, "삭제는 고유번호로만 가능합니다.\n삭제할 고유번호를 입력하세요!");
        txtSearch.requestFocus();
      }
      else {
        int sel = JOptionPane.showConfirmDialog(null, "정말로 삭제하시겠습니까?","삭제창",JOptionPane.OK_CANCEL_OPTION);
        if(sel != 0) {
          JOptionPane.showMessageDialog(null, "삭제가 취소 되었습니다.");
        }
        else {
          String word = txtSearch.getText();
          int ans = dao.delete(word); // 회원 삭제루틴 호출
          if(ans == 0) {
            JOptionPane.showMessageDialog(null, "삭제할 자료가 없습니다.");
            txtSearch.requestFocus();
          }
          else {
            JOptionPane.showMessageDialog(null, "삭제가 완료되었습니다.");
            initialize("allList", 1);
          }
        }
      }
    }
    else if(res == btnExit) {  // 종료처리
      dispose();
    }
  }
}
