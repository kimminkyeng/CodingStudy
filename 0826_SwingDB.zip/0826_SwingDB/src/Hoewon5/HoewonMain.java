package Hoewon5;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class HoewonMain extends JFrame {
  HoewonDao dao = new HoewonDao();
  private JButton btnInput, btnLogin, btnExit;
  private JLabel lblMid, lblPwd;
  private JTextField txtMid;
  private JPasswordField txtPwd;

  public static void main(String[] args) {
    EventQueue.invokeLater(new Runnable() {
      public void run() {
        try {
          HoewonMain window = new HoewonMain();
          window.setVisible(true);
        } catch (Exception e) {
          e.printStackTrace();
        }
      }
    });
  }

  public HoewonMain() {
    initialize();  // 화면디자인
  }

  private void initialize() {
    setTitle(" 회원관리(v5.0)");
    setBounds(100, 100, 550, 400);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLocationRelativeTo(null);
    getContentPane().setLayout(null);
    
    JLabel lblNewLabel = new JLabel("회 원 관 리 프 로 그 램(v5.0)");
    lblNewLabel.setFont(new Font("굴림", Font.BOLD, 24));
    lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
    lblNewLabel.setBounds(72, 46, 382, 51);
    getContentPane().add(lblNewLabel);
    
    btnLogin = new JButton("로 그 인");
    btnLogin.setFont(new Font("굴림", Font.PLAIN, 16));
    btnLogin.setBounds(58, 267, 100, 40);
    getContentPane().add(btnLogin);
    
    btnInput = new JButton("회원가입");
    btnInput.setFont(new Font("굴림", Font.PLAIN, 16));
    btnInput.setBounds(216, 267, 100, 40);
    getContentPane().add(btnInput);
    
    btnExit = new JButton("종  료");
    btnExit.setFont(new Font("굴림", Font.PLAIN, 16));
    btnExit.setBounds(374, 267, 100, 40);
    getContentPane().add(btnExit);
    
    lblMid = new JLabel("아 이 디");
    lblMid.setFont(new Font("굴림", Font.PLAIN, 16));
    lblMid.setBounds(130, 135, 100, 40);
    getContentPane().add(lblMid);

    lblPwd = new JLabel("비밀번호");
    lblPwd.setFont(new Font("굴림", Font.PLAIN, 16));
    lblPwd.setBounds(130, 195, 100, 40);
    getContentPane().add(lblPwd);
    
    txtMid = new JTextField(10);
    txtMid.setFont(new Font("굴림", Font.PLAIN, 16));
    txtMid.setBounds(250, 135, 100, 40);
    getContentPane().add(txtMid);

    txtPwd = new JPasswordField(10);
    txtPwd.setFont(new Font("굴림", Font.PLAIN, 16));
    txtPwd.setBounds(250, 195, 100, 40);
    getContentPane().add(txtPwd);

    // 버튼감시 리스너
    // 회원로그인버튼 클릭시
    btnLogin.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        loginCheck();
      }
    });
    // 회원로그인버튼을 엔터키로 눌렀을때...
    btnLogin.addKeyListener(new KeyAdapter() {
      public void keyPressed(KeyEvent e) {
        if(e.getKeyCode() == KeyEvent.VK_ENTER) {
          loginCheck();
        }
      }
    });
    
    // 회원가입 버튼 클릭시
    btnInput.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        txtMid.setText("");
        txtPwd.setText("");
        new HoewonInput();
      }
    });
    // 회원가입버튼을 엔터키로 누를시...
    btnInput.addKeyListener(new KeyAdapter() {
      public void keyPressed(KeyEvent e) {
        txtMid.setText("");
        txtPwd.setText("");
        new HoewonInput();
      }
    });
    
    // 종료버튼클릭시
    btnExit.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(null, "작업종료!\n수고하셨습니다.");
        System.exit(0);
      }
    });
    // 종료버튼을 엔터키로 누를때
    btnExit.addKeyListener(new KeyAdapter() {
      public void keyPressed(KeyEvent e) {
        JOptionPane.showMessageDialog(null, "작업종료!\n수고하셨습니다.");
        System.exit(0);
      }
    });
  }

  protected void loginCheck() {
    String mid = txtMid.getText();
    String pwd = txtPwd.getText();
    
    if(mid.trim().equals("")) {
      JOptionPane.showMessageDialog(null, "아이디를 입력하세요");
      txtMid.requestFocus();
    }
    else if(pwd.trim().equals("")) {
      JOptionPane.showMessageDialog(null, "비밀번호를 입력하세요");
      txtPwd.requestFocus();
    }
    else {
      String name = dao.loginCheck(mid, pwd);
      if(name == null) {
        JOptionPane.showMessageDialog(null, "회원정보가 없습니다.\n회원 가압하세요.");
        txtMid.requestFocus();
      }
      else {
        JOptionPane.showMessageDialog(null, name+"님 반갑습니다.");
        new HoewonMenu();
      }
    }
  }
}