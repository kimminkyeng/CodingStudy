package Hoewon5;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class HoewonUpdate extends JFrame {
  private JTextField txtMid, txtName;
  private JPasswordField txtPwd;
  private JButton btnSubmit, btnReset;

  public HoewonUpdate(HoewonVo vo) {
    initialize(vo);
  }

  private void initialize(HoewonVo vo) {
    setTitle("회원 정보 수정!");
    setBounds(100, 100, 550, 400);
    setLocationRelativeTo(null);
    getContentPane().setLayout(null);
    
    JLabel lblNewLabel = new JLabel("회 원 정 보 수 정");
    lblNewLabel.setFont(new Font("굴림", Font.BOLD, 18));
    lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
    lblNewLabel.setBounds(154, 10, 231, 39);
    getContentPane().add(lblNewLabel);
    
    JLabel lblId = new JLabel("회원 아이디");
    lblId.setHorizontalAlignment(SwingConstants.RIGHT);
    lblId.setFont(new Font("굴림", Font.PLAIN, 14));
    lblId.setBounds(50, 76, 147, 39);
    getContentPane().add(lblId);
    
    JLabel lblPwd = new JLabel("회원 비밀번호");
    lblPwd.setHorizontalAlignment(SwingConstants.RIGHT);
    lblPwd.setFont(new Font("굴림", Font.PLAIN, 14));
    lblPwd.setBounds(50, 159, 145, 39);
    getContentPane().add(lblPwd);
    
    JLabel lblName = new JLabel("성    명");
    lblName.setFont(new Font("굴림", Font.PLAIN, 14));
    lblName.setBounds(140, 239, 57, 15);
    getContentPane().add(lblName);
    
    txtMid = new JTextField(vo.getMid());
    txtMid.setFont(new Font("굴림", Font.PLAIN, 14));
    txtMid.setBounds(227, 76, 220, 39);
    getContentPane().add(txtMid);
    txtMid.setColumns(10);
    txtMid.setEnabled(false); // 아이디는 수정불가...
    
    txtPwd = new JPasswordField(vo.getPwd());
    txtPwd.setFont(new Font("굴림", Font.PLAIN, 14));
    txtPwd.setBounds(225, 159, 220, 39);
    getContentPane().add(txtPwd);
    txtPwd.setColumns(10);
    
    
    txtName = new JTextField(vo.getName());
    txtName.setFont(new Font("굴림", Font.PLAIN, 14));
    txtName.setBounds(227, 228, 220, 40);
    getContentPane().add(txtName);
    txtName.setColumns(10);
    
    btnSubmit = new JButton("정보수정");
    btnSubmit.setFont(new Font("굴림", Font.PLAIN, 14));
    btnSubmit.setBounds(100, 296, 145, 42);
    getContentPane().add(btnSubmit);
    
    btnReset = new JButton("수정취소");
    btnReset.setFont(new Font("굴림", Font.PLAIN, 14));
    btnReset.setBounds(295, 296, 152, 42);
    getContentPane().add(btnReset);
    
    setVisible(true);
    
    //수정 완료시 전송처리
    btnSubmit.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        String mid = txtMid.getText();
        String pwd = txtPwd.getText();
        String name = txtName.getText();
        
        if(pwd.trim().equals("")) {
          JOptionPane.showMessageDialog(null, "비밀번호를 입력하세요!");
          txtPwd.requestFocus();
        }
        else if(name.trim().equals("")) {
          JOptionPane.showMessageDialog(null, "성명을 입력하세요!");
          txtName.requestFocus();
        }
        else {
          HoewonDao dao = new HoewonDao();
          HoewonVo vo = new HoewonVo();
          
          vo.setMid(mid);
          vo.setPwd(pwd);
          vo.setName(name);
          System.out.println(vo);
          dao.getUpdate(vo);
          JOptionPane.showMessageDialog(null, "회원정보가 수정 되었습니다.");
          dispose();
        }
      }
    });
    
    btnReset.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(null, "회원정보 수정 취소!!");
        dispose();
      }
    });
    
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        dispose();
      }
    });
  }
}
