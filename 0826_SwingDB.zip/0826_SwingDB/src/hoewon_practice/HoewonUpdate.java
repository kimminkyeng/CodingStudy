package hoewon_practice;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.event.ActionEvent;

public class HoewonUpdate extends JFrame{
  private JTextField txtMid, txtName;
  private JPasswordField txtPwd;
  private JButton btnSubmit, btnReset;
  
  public HoewonUpdate(HoewonVo vo) {
    initialize(vo);
    }
  
  private void initialize(HoewonVo vo) {
    setTitle("회원 정보 수정");
    setBounds(100, 100, 550, 400);
    setLocationRelativeTo(null);
    getContentPane().setLayout(null);
    
    JLabel lblNewLabel = new JLabel("회 원 정 보 수 정");
    lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
    lblNewLabel.setFont(new Font("굴림", Font.BOLD, 18));
    lblNewLabel.setBounds(96, 10, 248, 37);
    getContentPane().add(lblNewLabel);
    
    JLabel lblId = new JLabel("아이디");
    lblId.setHorizontalAlignment(SwingConstants.RIGHT);
    lblId.setFont(new Font("굴림", Font.PLAIN, 14));
    lblId.setBounds(73, 57, 87, 31);
    getContentPane().add(lblId);
    
    JLabel lblPwd = new JLabel("비밀번호");
    lblPwd.setHorizontalAlignment(SwingConstants.RIGHT);
    lblPwd.setFont(new Font("굴림", Font.PLAIN, 14));
    lblPwd.setBounds(73, 144, 87, 31);
    getContentPane().add(lblPwd);
    
    JLabel lblName = new JLabel("성     명");
    lblName.setHorizontalAlignment(SwingConstants.RIGHT);
    lblName.setFont(new Font("굴림", Font.PLAIN, 14));
    lblName.setBounds(73, 217, 87, 31);
    getContentPane().add(lblName);
    
    txtMid = new JTextField();
    txtMid.setFont(new Font("굴림", Font.PLAIN, 14));
    txtMid.setBounds(172, 57, 201, 31);
    getContentPane().add(txtMid);
    txtMid.setColumns(10);
    txtMid.setEnabled(false);
    
    txtPwd = new JPasswordField();
    txtPwd.setFont(new Font("굴림", Font.PLAIN, 14));
    txtPwd.setBounds(172, 144, 201, 37);
    getContentPane().add(txtPwd);
    txtPwd.setColumns(10);
    
    txtName = new JTextField();
    txtName.setFont(new Font("굴림", Font.PLAIN, 14));
    txtName.setBounds(172, 214, 201, 37);
    getContentPane().add(txtName);
    txtName.setColumns(10);
    
    btnSubmit = new JButton("정 보 수 정");
    btnSubmit.setFont(new Font("굴림", Font.PLAIN, 14));
    btnSubmit.setBounds(63, 274, 120, 37);
    getContentPane().add(btnSubmit);
    
    btnReset = new JButton("수 정 취 소");
    btnReset.setFont(new Font("굴림", Font.PLAIN, 14));
    btnReset.setBounds(253, 274, 120, 37);
    getContentPane().add(btnReset);
    
    setVisible(true);
    
    //수정완료시 전송처리
    btnSubmit.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        String mid = txtMid.getText();
        String pwd = txtPwd.getText();
        String name = txtName.getText();
        
        if(pwd.trim().equals("")) {
          JOptionPane.showMessageDialog(null, "비밀번호를 입력하세요.");
          txtPwd.requestFocus();
        }
        else if(name.trim().equals("")) {
          JOptionPane.showMessageDialog(null, "성명을 입력하세요.");
          txtName.requestFocus();
        }
        else {
          HoewonDao dao = new HoewonDao();
          HoewonVo vo = new HoewonVo();
          
          vo.setMid(mid);
          vo.setPwd(pwd);
          vo.setName(name);
          System.out.println(vo);
          dao.getUpdate(vo);
          JOptionPane.showMessageDialog(null, "회원정보가 수정되었습니다.");
          dispose();
        }
      }
    });
    // 수정취소
    btnReset.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(null, "회원정보 수정이 취소되었습니다.");
        dispose();
      }
    });
    
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        dispose();
      }
    });
  }
}
