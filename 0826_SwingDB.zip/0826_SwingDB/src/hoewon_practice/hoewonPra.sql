show tables;

create table hoewonPra(
  idx int not null auto_increment primary key,
  mid varchar(20) not null,
  pwd varchar(20) not null,
  name varchar(20) not null
);

desc hoewonPra;

insert into hoewonPra values (default, 'hkd1234','1234','홍길동');
insert into hoewonPra values (default, 'kms1234','1234','김말숙');
insert into hoewonPra values (default, '222','222','연습자료');

select * from hoewonPra;
select * from hoewonPra where name = '홍길순';
select * from hoewonPra where name like '%나무%';

/*delete from exam where name='';*/