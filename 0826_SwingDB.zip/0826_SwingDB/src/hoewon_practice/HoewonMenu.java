package hoewon_practice;

import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;

import Hoewon5.HoewonList;
import Hoewon5.HoewonUpdate;

import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;

public class HoewonMenu extends JFrame {
    HoewonDao dao = new HoewonDao();
    private JButton btnUpdate, btnList, btnExit;
    
    public static void main(String[] args) {
      EventQueue.invokeLater(new Runnable() {
        public void run() {
          try {
            HoewonMenu window = new HoewonMenu();
            window.setVisible(true);
          } catch (Exception e) {
            e.printStackTrace();
          }
        }
      });
    }
    
  public HoewonMenu() {
    initialize();  // 화면디자인
  }

  private void initialize() {
    setTitle(" 회원관리(v5.0)");
    setBounds(100, 100, 550, 400);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLocationRelativeTo(null);
    getContentPane().setLayout(null);
    
    JLabel lblNewLabel = new JLabel("회 원 관 리");
    lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
    lblNewLabel.setFont(new Font("굴림", Font.BOLD, 24));
    lblNewLabel.setBounds(60, 36, 422, 51);
    getContentPane().add(lblNewLabel);
    
    JButton btnUpdate = new JButton("회원정보수정");
    btnUpdate.setFont(new Font("굴림", Font.PLAIN, 16));
    btnUpdate.setBounds(38, 249, 135, 42);
    getContentPane().add(btnUpdate);
    
    JButton btnList = new JButton("전 체 조 회");
    btnList.setFont(new Font("굴림", Font.PLAIN, 16));
    btnList.setBounds(211, 249, 135, 42);
    getContentPane().add(btnList);
    
    JButton btnExit = new JButton("종        료");
    btnExit.setFont(new Font("굴림", Font.PLAIN, 16));
    btnExit.setBounds(384, 249, 135, 42);
    getContentPane().add(btnExit);
    
    setVisible(true);
    
    // 회원수정
    btnUpdate.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        String mid = JOptionPane.showInputDialog("수정할 회원의 아이디를 입력하세요");
        HoewonVo vo = dao.search(mid);
        if(vo == null) {
          JOptionPane.showMessageDialog(null, "회원의 아이디가 맞지 않습니다.");
        }
        else {
          new hoewon_practice.HoewonUpdate(vo);
        }
      }
    });
    
    // 회원전체조회
    btnList.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        new HoewonList();
      }
    });
    // 종료
    btnExit.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(null, "작업종료!\n수고하셨습니다.");
        System.exit(0);
      }
    });
    // 종료(키보드 엔터로도 종료)
    btnExit.addKeyListener(new KeyAdapter() {
      @Override
      public void keyPressed(KeyEvent e) {
        JOptionPane.showMessageDialog(null, "작업종료!\n수고하셨습니다.");
        System.exit(0);
      }
    });
    
  }
}
