package hoewon_practice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class HoewonDao {
  private Connection conn;
  private PreparedStatement pstmt;
  private ResultSet rs;
  private String sql = "";
  
  private String driver = "com.mysql.jdbc.Driver";
  private String url = "jdbc:mysql://localhost:3306/javadb";
  private String user = "root";
  private String password="1234";
  
  private Vector vData;
  
  // 기본생성자
  public HoewonDao() {}
  
  // 커넥션객체생성(DB연동)
  public Connection getConn() {
    try {
      Class.forName(driver);
      conn = DriverManager.getConnection(url, user, password);
      } 
      catch (ClassNotFoundException e) {
      System.out.println("드라이버 검색 실패" + e.getMessage());
      }
      catch (SQLException e) {
      System.out.println("DB연동 오류!" + e.getMessage());
      }
    return conn;
  }
  
  // DB(Rs) Close
  public void getRsClose() {
    try {
      rs.close();
      if(pstmt != null) pstmt.close();
      if(conn != null) conn.close();
    } catch (SQLException e) {}
  }

  // DB(Conn) Close
  public void getConnClose() {
      try {
        if(pstmt != null) pstmt.close();
        if(conn != null) conn.close();
      } catch (SQLException e) {}
  }
  
  public Vector getHoewonList() {
    vData = new Vector();
    try {
      conn = getConn();
      sql = "select * from hoewonPra order by name";
      pstmt = conn.prepareStatement(sql);
      rs = pstmt.executeQuery();
      
      while(rs.next()) {
        int idx = rs.getInt("idx");
        String mid = rs.getString("mid");
        String pwd = rs.getString("pwd");
        String name = rs.getString("name");
        
        Vector row = new Vector();
        row.add(idx);
        row.add(mid);
        row.add(pwd);
        row.add(name);
        
        vData.add(row);
      }
      getRsClose();
    } catch (SQLException e) {
      System.out.println("SQL 에러!!" + e.getMessage());
    }
    return vData;
  }
  
  public Vector search(String gubun, String word) {
    vData = new Vector();
    try {
      conn = getConn();
      if(gubun.equals("idx")) {
        sql = "select * from hoewonPra where idx=? order by name";
      }
      else if(gubun.equals("mid")) {
        sql = "select * from hoewonPra where mid=? order by name";
      }
      else {
        sql = "select * from hoewonPra where name like ? order by name";
      }
      pstmt = conn.prepareStatement(sql);
      
     if(gubun.equals("idx")) {
       int iWord = Integer.parseInt(word);
       pstmt.setInt(1, iWord);
     }
     else if(gubun.equals("mid")) {
       pstmt.setString(1, word);
     }
     else {
       pstmt.setString(1, "%"+word+"%");
     }
     rs = pstmt.executeQuery();
     
     while(rs.next()) {
       int idx = rs.getInt("idx");
       String mid = rs.getString("mid");
       String pwd = rs.getString("pwd");
       String name = rs.getString("name");
       
       Vector row = new Vector();
       row.add(idx);
       row.add(mid);
       row.add(pwd);
       row.add(name);
       
       vData.add(row);
     }
     getRsClose();
    } catch (SQLException e) {
      System.out.println("SQL 에러!!" + e.getMessage());
    }
    return vData;
  }
  public int delete(String word) {
    try {
      conn = getConn();
      int iWord = Integer.parseInt(word);
      sql = "select * from hoewonPra where idx=?";
      pstmt = conn.prepareStatement(sql);
      pstmt.setInt(1, iWord);
      rs = pstmt.executeQuery();
      if(!rs.next()) {
        rs.close();
        return 0; //찾는게 없을땐 0으로 리턴.
      }
      else {
        if(pstmt != null) pstmt.close();
        sql = "delete from hoewonPra where idx=?";
        pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, iWord);
        pstmt.executeUpdate();
        getConnClose();
      }
    } catch (SQLException e) {
      System.out.println("SQL 에러!!" + e.getMessage());
    }
    return 1;
  }
  
  // 회원가입하기
  public int getInput(HoewonVo vo) {
    try {
      conn = getConn();
      sql = "select * from hoewonPra where mid=?";
      pstmt = conn.prepareStatement(sql);
      pstmt.setString(1, vo.getMid());
      rs = pstmt.executeQuery();
      if(rs.next()) {
        rs.close();
        return 0;
      }
      else {
        sql = "insert into hoewonPra values (default,?,?,?);";
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, vo.getMid());
        pstmt.setString(2, vo.getPwd());
        pstmt.setString(3, vo.getName());
        pstmt.executeUpdate();
        getConnClose();
        return 1;
      }
    } catch (SQLException e) {
      System.out.println("SQL 에러!!" + e.getMessage());
    }
    return 0;
  }
  public HoewonVo search(String mid) {
    HoewonVo vo = new HoewonVo();
    conn = getConn();
    sql = "select * from HoewonPra where mid=?";
    try {
      pstmt = conn.prepareStatement(sql);
      pstmt.setString(1, mid);
      rs = pstmt.executeQuery();
      if(!rs.next()) {
        rs.close();
        return null;
      }
      else {
        vo.setMid(mid);
        vo.setPwd(rs.getString("pwd"));
        vo.setName(rs.getString("name"));
        getRsClose();
      }
    } catch (SQLException e) {
      System.out.println("SQL 에러!!" + e.getMessage());
    }
    return vo;
  }
  public void getUpdate(HoewonVo vo) {
    conn = getConn();
    sql = "update HoewonPra set pwd=?, name=? where mid=?";
    try {
      pstmt = conn.prepareStatement(sql);
      pstmt.setString(1, vo.getPwd());
      pstmt.setString(2, vo.getName());
      pstmt.setString(1, vo.getMid());
      pstmt.executeUpdate();
      getConnClose();
    } catch (SQLException e) {
      System.out.println("SQL 에러!!" + e.getMessage());
    }
  }
  public String loginCheck(String mid, String pwd) {
    String name;
    try {
      conn = getConn();
      sql = "select * from HoewonPra where mid=? and pwd=?";
      pstmt = conn.prepareStatement(sql);
      pstmt.setString(1, mid);
      pstmt.setString(2, pwd);
      rs = pstmt.executeQuery();
      if(!rs.next()) {
        rs.close();
        return null;  // 찾는자로가 없을시는 'null'을 리턴한다.
      }
      else {
        name = rs.getString("name");
        getRsClose();
        return name;
      }
    } catch (SQLException e) {
      System.out.println("SQL 에러!!" + e.getMessage());
    }
    return null;
 }
}