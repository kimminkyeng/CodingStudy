package hoewon_practice;

import java.awt.BorderLayout;
import java.util.Vector;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class HoewonList extends JFrame {
  private HoewonDao dao = new HoewonDao();
  private Vector vData, cols;
  private DefaultTableModel model;
  private JTable jTable;
  private JScrollPane jspan;
  private JPanel jpan1;
  private JButton btnSearch, btnList, btnDelete, btnExit;
  private JComboBox<String> combo;
  private String[] items = {"고유번호","아이디","비밀번호"};
  private JButton button;
  private JButton button_1;
  private JTextField txtSearch;
  
  public HoewonList() {
    super("회원 전체 조회");
    setSize(531, 300);
    setLocationRelativeTo(null);
    vData = dao.getHoewonList();
    cols = getColumn();
    model = new DefaultTableModel(vData, cols);
    getContentPane().setLayout(null);
    jTable = new JTable(model);
    jspan = new JScrollPane(jTable);
    jspan.setBounds(0, 44, 515, 217);
    getContentPane().add(jspan, BorderLayout.CENTER);
    
    getContentPane().add(jspan);
    
    JPanel pnTop = new JPanel();
    pnTop.setBounds(0, 0, 515, 44);
    getContentPane().add(pnTop);
    pnTop.setLayout(null);
    
    JButton btnSearch = new JButton("조건검색");
    btnSearch.setBounds(236, 10, 81, 24);
    pnTop.add(btnSearch);
    
    btnList = new JButton("전체검색");
    btnList.setBounds(329, 10, 81, 24);
    pnTop.add(btnList);
    
    btnExit = new JButton("종료");
    btnExit.setBounds(422, 10, 81, 24);
    pnTop.add(btnExit);
    
    JComboBox comboBox = new JComboBox();
    comboBox.setModel(new DefaultComboBoxModel(new String[] {"고유번호", "아이디", "비밀번호"}));
    comboBox.setBounds(12, 10, 87, 24);
    pnTop.add(comboBox);
    
    txtSearch = new JTextField();
    txtSearch.setBounds(111, 12, 101, 22);
    pnTop.add(txtSearch);
    txtSearch.setColumns(10);
    
    setVisible(true);
    
    //전체검색
    btnList.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        dispose();
        new HoewonList();
      }
    });
    
    //조건검색
    btnSearch.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        String word = txtSearch.getText();
        String comboStr = (String) comboBox.getSelectedItem();
        
        if(word.equals("")) {
          JOptionPane.showMessageDialog(null, "검색어를 입력하세요.");
          txtSearch.requestFocus();
        }
        else {
          if(comboStr.equals("고유번호")) {
            vData = dao.search("idx",word);
          }
          else if(comboStr.equals("아이디")) {
            vData = dao.search("mid", word);
          }
          else {
            vData = dao.search("pwd", word);
          }
          //System.out.println("vData=" + vData);
          model.setDataVector(vData, cols);
        }
      }
    });
    
   //종료
    btnExit.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        //System.exit(0);
        dispose();
      }
    });
   //종료를 키보드 엔터로도 종료
    btnExit.addKeyListener(new KeyAdapter() {
      @Override
      public void keyPressed(KeyEvent e) {
        //System.exit(0);
        dispose();
      }
    });
  }
  private Vector getColumn() {
    Vector cols = new Vector();
    cols.add("고유번호");
    cols.add("아이디");
    cols.add("비밀번호");
    
    return cols;
  }
  public static void main(String[] args) {
    new HoewonList();
  }
}
