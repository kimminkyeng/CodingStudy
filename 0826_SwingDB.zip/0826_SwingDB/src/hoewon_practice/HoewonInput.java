package hoewon_practice;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;

import Hoewon5.HoewonDao;
import Hoewon5.HoewonVo;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.event.ActionEvent;

public class HoewonInput extends JFrame {
  private JTextField txtMid;
  private JPasswordField txtPwd;
  private JTextField txtName;
  private JButton btnSubmit, btnReset;
  
  public static void main(String[] args) {
    new HoewonInput();
  }
  
  public HoewonInput() {
    initialize();
  }
  public void initialize() {
    setTitle("회원 가입!");
    setBounds(100, 100, 550, 400);
    setLocationRelativeTo(null);
    getContentPane().setLayout(null);
    
    JLabel lblNewLabel = new JLabel("회 원 가 입");
    lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
    lblNewLabel.setFont(new Font("굴림", Font.BOLD, 18));
    lblNewLabel.setBounds(148, 12, 227, 44);
    getContentPane().add(lblNewLabel);
    
    JLabel lblId = new JLabel("아이디");
    lblId.setFont(new Font("굴림", Font.PLAIN, 14));
    lblId.setHorizontalAlignment(SwingConstants.RIGHT);
    lblId.setBounds(75, 89, 117, 37);
    getContentPane().add(lblId);
    
    JLabel lblPwd = new JLabel("비밀번호");
    lblPwd.setHorizontalAlignment(SwingConstants.RIGHT);
    lblPwd.setFont(new Font("굴림", Font.PLAIN, 14));
    lblPwd.setBounds(75, 153, 117, 37);
    getContentPane().add(lblPwd);
    
    JLabel lblName = new JLabel("성    명");
    lblName.setHorizontalAlignment(SwingConstants.RIGHT);
    lblName.setFont(new Font("굴림", Font.PLAIN, 14));
    lblName.setBounds(75, 213, 117, 37);
    getContentPane().add(lblName);
    
    txtMid = new JTextField();
    txtMid.setFont(new Font("굴림", Font.PLAIN, 14));
    txtMid.setBounds(222, 96, 212, 30);
    getContentPane().add(txtMid);
    txtMid.setColumns(10);
    
    txtPwd = new JPasswordField();
    txtPwd.setFont(new Font("굴림", Font.PLAIN, 14));
    txtPwd.setBounds(222, 160, 212, 30);
    getContentPane().add(txtPwd);
    txtPwd.setColumns(10);
    
    txtName = new JTextField();
    txtName.setFont(new Font("굴림", Font.PLAIN, 14));
    txtName.setBounds(222, 213, 212, 37);
    getContentPane().add(txtName);
    txtName.setColumns(10);
    
    btnSubmit = new JButton("가 입 완 료");
    btnSubmit.setFont(new Font("굴림", Font.PLAIN, 14));
    btnSubmit.setBounds(58, 280, 162, 37);
    getContentPane().add(btnSubmit);
    
    btnReset = new JButton("가 입 취 소");
    btnReset.setFont(new Font("굴림", Font.PLAIN, 14));
    btnReset.setBounds(264, 280, 162, 37);
    getContentPane().add(btnReset);
    
    setVisible(true);
    //회원 가입 버튼 클릭시
    btnSubmit.addActionListener(new ActionListener() { //new ActionListener()에 커서 놓고 ctrl+space bar 누르고 인터페이스 누르면 오버라이딩 나옴.
      @Override
      public void actionPerformed(ActionEvent e) {
        String mid = txtMid.getText();
        String pwd = txtPwd.getText();
        String name = txtName.getText();
        
        if(mid.trim().equals("")) {
          JOptionPane.showMessageDialog(null, "아이디를 입력하세요!");
          txtMid.requestFocus();
        }
        else if(pwd.trim().equals("")) {
          JOptionPane.showMessageDialog(null, "비밀번호를 입력하세요!");
          txtPwd.requestFocus();
        }
        else if(name.trim().equals("")) {
          JOptionPane.showMessageDialog(null, "성명을 입력하세요!");
          txtName.requestFocus();
        }
        else {
          HoewonDao dao = new HoewonDao();
          HoewonVo vo = new HoewonVo();
          
          vo.setMid(mid);
          vo.setPwd(pwd);
          vo.setName(name);
          int res = dao.getInput(vo);
          if(res == 1) {
            JOptionPane.showMessageDialog(null, "회원가입 되셨습니다.");
            dispose();
          }
          else {
            JOptionPane.showMessageDialog(null, "동일한 아이디가 존재합니다.\n다른 아이디로 가입하세요.");
            txtMid.requestFocus();
          }
        }
      }
    });
    
  //회원 가입 버튼 클릭시
    btnReset.addActionListener(new ActionListener() {
      
      @Override
      public void actionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(null, "회원 가입이 취소되었습니다.");
        dispose();
      }
    });
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        dispose();
      }
    });
  }
}
