package T_0717;

import java.util.Random;
import java.util.Scanner;

public class Exam_07272 {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    Random random = new Random();
    int com = random.nextInt(100);
    int input;
    int cnt = 0;

    do {
      System.out.println("숫자를 입력하세요. ");
      input = sc.nextInt();
          cnt++;
        if(cnt<5) {
          if(input<com) {
             System.out.println("높은수를 입력하세요");
            }
          else {
         System.out.println("낮은수를 입력하세요");
       } 
        }
        else {
          System.out.println("도전실패");
        }
      } while(input != com);
    
    System.out.println("정답입니다.");
    System.out.println("정답까지"+ cnt +"번 입력하였습니다.");
    sc.close();
     }
  }


