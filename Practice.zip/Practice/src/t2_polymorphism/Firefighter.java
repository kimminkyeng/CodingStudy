package t2_polymorphism;

public class Firefighter {
  void firefighterRun() {
    System.out.println("불을 끕니다.");
  }
}
