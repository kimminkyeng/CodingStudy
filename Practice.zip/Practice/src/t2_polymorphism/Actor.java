package t2_polymorphism;

public class Actor extends Chef {
  void actorRun() {
    System.out.println("연기를 합니다.");
  }

  @Override
  void taxidriverRun() {
   // super.taxidriverRun(); 생략가능
    System.out.println("배우는 도로주행을 합니다.");
  }
  
  
  
}
