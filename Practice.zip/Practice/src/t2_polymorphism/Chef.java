package t2_polymorphism;

public class Chef extends Taxidriver{
  void chefRun() {
    System.out.println("스파게티를 만듭니다.");
  }
}
