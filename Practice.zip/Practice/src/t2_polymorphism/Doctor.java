package t2_polymorphism;

public class Doctor extends Firefighter{
  void doctorRun() {
    System.out.println("환자를 치료합니다.");
  }
}
