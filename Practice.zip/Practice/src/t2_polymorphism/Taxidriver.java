package t2_polymorphism;

public class Taxidriver extends Doctor {
  void taxidriverRun() {
    System.out.println("시내주행을 합니다.");
  }
}
