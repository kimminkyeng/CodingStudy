package t2_polymorphism;

import java.util.Scanner;

public class TestRun {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    int num;
    boolean flag = true;
    
    Firefighter firefighter = new Actor(); //업캐스팅
    
    Actor actor = (Actor) firefighter; //다운캐스팅
    actor.actorRun();
    
    while(flag) {
      System.out.println("==============================");
      System.out.println("*** 배우가 하고 싶은 역할은?");
      System.out.print("1.소방관 | 2.의사 | 3.택시운전사 | 4.요리사 | 5.도로주행 | 6.종료  ==> ");
      num = sc.nextInt();
      
      switch(num) {
        case 1:
          firefighter.firefighterRun();
          break;
        case 2:
          Doctor doctor = (Doctor) firefighter;
          doctor.doctorRun();
          break;
        case 3:
          Taxidriver taxidriver = (Taxidriver) firefighter;
          taxidriver.taxidriverRun(); //Taxidriver 클래스에 오버라이딩 되어있는 taxidriverRun();.
         break;
        case 4:
          Chef chef = (Chef) firefighter;
          chef.chefRun();
         break;
        case 5:
          actor.taxidriverRun(); //Actor 클래스에 오버라이딩 되어있는 taxidriverRun();.
         break;
         
        default:
          System.out.println("==================================");
          actor.actorRun();
          System.out.println("==================================");
          flag = false; //반복문 마무리. break 안줘도 됨.
      }
    }
    System.out.println("작업끝!");  
      
    sc.close();
  }
}
