package t4_abstract;

public class WoojuBunsik extends Bonsa {

  @Override
  public void price() {
    kimChiJjiGae = 6000;
    budaeJjiGae = 7000;
    biBimBap = 7000;
    SoonDaekuk = 6000;
    gongKiBap = 1000;
  }
}
