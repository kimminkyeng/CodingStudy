package t4_abstract;

public class SeoulBunsik extends Bonsa {

  @Override
  public void price() {
    kimChiJjiGae = 5000;
    budaeJjiGae = 5000;
    biBimBap = 5000;
    SoonDaekuk = 4000;
    gongKiBap = 0;
   }
  }
