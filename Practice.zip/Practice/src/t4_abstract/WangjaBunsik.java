package t4_abstract;

public class WangjaBunsik extends Bonsa {
  
  @Override
  public void price() {
    kimChiJjiGae = 4500;
    budaeJjiGae = 5000;
    biBimBap = 6000;
    SoonDaekuk = -1;
    gongKiBap = 1000;
  }
}
