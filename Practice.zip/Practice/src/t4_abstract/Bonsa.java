package t4_abstract;

public abstract class Bonsa {
  public int kimChiJjiGae;
  public int budaeJjiGae;
  public int biBimBap;
  public int SoonDaekuk;
  public int gongKiBap;
  
  public Bonsa () {}
  
  public void menu() {
    if(kimChiJjiGae != -1)
      System.out.println("김치찌게 : " + kimChiJjiGae);
    else
      System.out.println("김치찌게는 판매하지 않습니다.");
  }
  
  public abstract void price();
  
  }
