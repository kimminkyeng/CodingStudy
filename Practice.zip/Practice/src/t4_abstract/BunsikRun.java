package t4_abstract;

import java.util.Scanner;

public class BunsikRun {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    int choice;
    boolean flag = true;
    
    while(flag) {
      System.out.println("====================");
      System.out.println("분식점을 선택하세요");
      System.out.print("1.왕자  2.우주  3.서울  4.종료 ==> ");
      choice = sc.nextInt();
      System.out.println();
      
      switch(choice) {
      case 1:
        Bonsa bonsa = new WangjaBunsik();
        bonsa.price();
        bonsa.menu();
        break;
        default:
          System.out.println("작업끝!!");
     }
    }
    sc.close();
  }
}
