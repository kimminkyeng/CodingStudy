package t3_abstract;

public class Cat extends Animal {

  @Override
  public void sound() {
    System.out.println("고양이 울음소리는 야옹 입니다.");
  }

}
