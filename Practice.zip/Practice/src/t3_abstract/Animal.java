package t3_abstract;
//추상클래스 (추상클래스는 추상메소드와 일반메소드 전부 포함시킨다. 그리고 외부클래스에서 가져올수가 없다. 무조건 상속된관계 안에서만 가능하다.)
public abstract class Animal { //추상메소드
  public void sound0() { //일반메소드
    System.out.println("울음소리 연구");
  }
  
  public abstract void sound(); //추상메소드가 됨.{} 넣으면 에러남.
}
