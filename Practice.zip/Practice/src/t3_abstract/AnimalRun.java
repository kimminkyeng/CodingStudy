package t3_abstract;

public class AnimalRun {
  public static void main(String[] args) {
    Animal animal; //부모타입이 추상클래스니 객체를 생성할수가 없다.
    animal = new Dog();   // Animal animal = new Dog();
    animal.sound();

    animal = new Cat();
    animal.sound();
    
    animal = new Mouse();
    animal.sound();
  }
}
