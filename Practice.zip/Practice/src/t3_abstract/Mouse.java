package t3_abstract;

public class Mouse extends Animal {

  @Override
  public void sound() {
    System.out.println("쥐의 울음소리는 찍찍 입니다.");
  }
}
