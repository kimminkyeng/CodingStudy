package t3_abstract;

public class Dog extends Animal {

  @Override
  public void sound() {
   System.out.println("강아지의 울음소리는 멍멍 입니다.");

  }
  
  public void sound0() { //추상클래스 안에 일반메소드를 오버라이딩 한것.
    System.out.println("소리 연구");
  }
}
