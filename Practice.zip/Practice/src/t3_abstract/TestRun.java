package t3_abstract;

public class TestRun {
  public static void main(String[] args) {
   // Animal animal = new Animal(); //외부에서 가져올수 없음.
    Dog dog = new Dog();
    dog.sound();
    dog.sound0();
    System.out.println();
    
    Cat cat = new Cat();
    cat.sound();
    cat.sound0(); //부모클래스것이 나옴.
    System.out.println();
    
    Mouse mouse = new Mouse();
    mouse.sound();
    mouse.sound0(); //부모클래스것이 나옴.
    
  }
}
