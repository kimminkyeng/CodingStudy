package t1_polymorphism;

public class AService extends MemberService {

}
