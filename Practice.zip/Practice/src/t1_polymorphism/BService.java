package t1_polymorphism;

public class BService extends MemberService{

}
