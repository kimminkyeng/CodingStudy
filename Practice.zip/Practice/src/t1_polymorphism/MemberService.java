package t1_polymorphism;

public class MemberService extends Service {

}
