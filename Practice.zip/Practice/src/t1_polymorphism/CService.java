package t1_polymorphism;

public class CService extends BoardService {

}
