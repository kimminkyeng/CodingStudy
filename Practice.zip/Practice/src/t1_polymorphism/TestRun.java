package t1_polymorphism;

public class TestRun {
  public static void main(String[] args) {
    Controller controller = new Controller();
    
    MemberService memberService = new MemberService();
    
    controller.setService(memberService);
    controller.setService(new MemberService());
    //controller.setService(new Service());
    controller.setService(new AService());
    controller.setService(new BService());
    controller.setService(new AAService());
    //controller.setService(new BoardService());
    //controller.setService(new CService());
    //controller.setService(new CCService());
    
    System.out.println("작업끝!^^");
  }
}
