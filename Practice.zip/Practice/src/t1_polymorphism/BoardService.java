package t1_polymorphism;

public class BoardService extends Service {

}
