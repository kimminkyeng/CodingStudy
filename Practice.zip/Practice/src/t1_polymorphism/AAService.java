package t1_polymorphism;

public class AAService extends AService {

}
