package t1_polymorphism;

public class Service {
  public MemberService service;
  
  public void setService(MemberService service) {
    this.service = service;
  }
}
