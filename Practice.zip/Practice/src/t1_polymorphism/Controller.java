package t1_polymorphism;

public class Controller {
  public MemberService service;
  
  public void setService(MemberService service) {
    if(service instanceof MemberService) {
      this.service = service;
      System.out.println("객체타입변환 성공!!!");
    }
  }
}
