package t1_polymorphism;

public class CCService extends CService {

}
