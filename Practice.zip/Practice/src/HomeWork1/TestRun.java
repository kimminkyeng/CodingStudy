package HomeWork1;

public class TestRun {

  public void main(String[] args) {
    //Controller controller = new Controller();
    //Controller.setService(Service service);
    
    //MemberService memberService = memberService;
    //AService aService = aService;
    //BService bService = bService;
    //AAService aaService = aaService;
    
    
    
    
  }
}
