package HomeWork1;

public class CService extends BoardService {

}
