package HomeWork1;

public class AAService extends AService {

}
