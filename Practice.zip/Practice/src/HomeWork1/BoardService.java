package HomeWork1;

public class BoardService extends Service {

}
