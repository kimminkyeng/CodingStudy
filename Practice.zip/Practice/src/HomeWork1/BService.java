package HomeWork1;

public class BService extends MemberService {

}
