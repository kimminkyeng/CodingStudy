package HomeWork1;

public class AService extends MemberService {

}
