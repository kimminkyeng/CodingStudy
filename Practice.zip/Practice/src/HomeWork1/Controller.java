package HomeWork1;

public class Controller {
  public MemberService service;
  public void setService(MemberService service) {
    this.service = service;
  }

}
