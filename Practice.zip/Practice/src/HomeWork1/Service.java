package HomeWork1;

public class Service {


}
