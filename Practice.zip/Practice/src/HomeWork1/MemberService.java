package HomeWork1;

public class MemberService extends Service {

}
