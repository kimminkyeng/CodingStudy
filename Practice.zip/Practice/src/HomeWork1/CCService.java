package HomeWork1;

public class CCService extends CService {

}
