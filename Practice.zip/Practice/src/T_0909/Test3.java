package T_0909;

public class Test3 {
  public static void main(String[] args) {
    System.out.println("Hello World"); //String (문자열)
//    System.out.println('Hello World'); //작은따옴표는 JAVA에서는 Character 타입에만 쓰임. 현재는 에러남.
    System.out.println('H'); //Character(한 문자)
    System.out.println("H"); //출력가능
    
    System.out.println("Hello"
        + "World"); //"HelloWorld"로 출력가능 (줄바꿈은 안됨)
//    System.out.println("Hello"
//        World); 에러남

    // \n (New line)
    System.out.println("Hello \nWorld"); //"Hello (다음줄에)World"로 출력가능 (줄바꿈 가능)
    
    // \"문자열\" (escape)
    System.out.println("Hello \"World\""); // 결과 : Hello "World"
  }
}
