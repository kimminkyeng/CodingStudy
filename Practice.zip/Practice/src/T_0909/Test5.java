package T_0909;

public class Test5 {
  public static void main(String[] args) {
    //Variable(변수)
    
    // a = 1; 그냥 이렇게 치면 결과는 에러가 나옴.
    int a;
    a = 1; // 1은 Integer. 최신 이클립스에서는 'int a = 1;' 이렇게 써도 에러가 안나나, 여기서는 에러가남.
    System.out.println(a);
    
//    int b;
//    b = 1.1; //1.1은 정수가 아니라서 에러가 남. 실수(real number)임.
    
    double b;
    b = 1.1;
    System.out.println(b);
    
//    int c;
//    c= "Hello World"; //"Hello World"는 문자열이라서(정수가 아니라서) 에러가 남.
    
    String c;
    c= "Hello World";
    System.out.println(c);
  }
}
