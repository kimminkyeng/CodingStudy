package T_0909;

public class Test7 {
  public static void main(String[] args) {
    
    double a = 1.1;
//    1; //Integer
    double b = 1;
    double b2 = (double)1; //수동으로(명시적으로) 작업
    System.out.println(b); //결과 : 1.0;
    System.out.println(b2); //결과 : 1.0;
    
//    1.1; 은 double 타입.
    
//    int c = 1.1; 에러결과 : Exception in thread "main" java.lang.Error: Unresolved compilation problem: Type mismatch: cannot convert from double to int
      double d = 1.1; // int에서 double로 바뀜
      int e = (int) 1.1; //Add cast to 'int'. 수동으로(명시적으로) 작업
      System.out.println(e); //결과 : 1
      
      // 1 to String
      String f = Integer.toString(1); //Integer.toString(1) : 정수를 문자로 변환.
      System.out.println(f); //결과 : 1 (뒤에 .getClass() 쓰면 결과는 'class java.lang.String' <- 이렇게 나옴. 1이 문자타입이라는 것을 나타냄)
      System.out.println(f.getClass());
  }
}
