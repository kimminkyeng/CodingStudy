package T_0909;

import javax.swing.JOptionPane;

import opentutorials.iot.DimmingLights;
import opentutorials.iot.Elevator;
import opentutorials.iot.Lighting;
import opentutorials.iot.Security;

public class OkJavaGoInHome {
  public static void main(String[] args) {
      String id = JOptionPane.showInputDialog("Enter a ID");
      String bright = JOptionPane.showInputDialog("Enter a Bright level");
      
    // Elevator call
      Elevator myElevator = new Elevator(id);
      myElevator.callForUp(1);
    
    // Security off
      Security mySecurity = new Security(id);
      mySecurity.off();
    
    // Light on
      Lighting hallLamp = new Lighting(id);
      hallLamp.on();
    
      Lighting floorLamp = new Lighting(id);
      floorLamp.on();
      
      DimmingLights moodLamp = new DimmingLights(id+" moodLamp");
      moodLamp.setBright(Double.parseDouble(bright)); //Double.parseDouble(bright) : String형 bright가 double형으로 변경됨.
      moodLamp.on();
  }
}
