package T_0909;

public class Test1 {
  public static void main(String[] args) {
    System.out.println(6); //Number
    System.out.println("six"); //String
    
    System.out.println("6"); //String 6
    System.out.println(6+6); //Number
    System.out.println("6+6"); //String
    System.out.println("6"+"6"); //String
    
    System.out.println(6*6); //Number
//    System.out.println("6"*"6"); // 에러나옴
    
    System.out.println("1111".length()); //length는 문자열의 길이. 결과 : 4
//    System.out.println(1111.length()); //에러나옴
  }
}
