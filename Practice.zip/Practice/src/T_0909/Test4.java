package T_0909;

public class Test4 {
    public static void main(String[] args) {
      
      System.out.println("Hello World".length()); //결과 : 11 (11개 문자)
      System.out.println("Hello, Leexdfs ... bye".replace("Leexdfs","egoing")); //결과 : Hello, egoing ... bye
      System.out.println("Hello, [name] ... bye".replace("[name]","egoing")); //결과 : Hello, egoing ... bye
      System.out.println("Hello, [name] ... bye".replace("[name]","duru")); //결과 : Hello, duru ... bye
    }

}
