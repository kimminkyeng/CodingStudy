package T_0704;

public class Test2 {
  public static void main(String[] args) {
    
    
    
    byte ba=10;
    byte bb=20;
    byte bc=10+20;
    //byte bd=ba+bb;   // 타입 캐스팅 에러
    byte be=(byte)(ba+bb); // (byte)(int+int)
    System.out.println("01 : "+bc);
    System.out.println("01 : "+be);
    
    short sa = 30;
    short sb = 50;
    short sc = 30+50;
    // short sd=sa+sb; // 타입 캐스팅 에러
    short se=(short)(sa+sb);   //(short)(int+int)
    System.out.println("03 : "+sc);
    System.out.println("04 : "+se);
    
    int ia=20;
    int ib=30;
    int ic=20+30;
    int id=ic+sa;  //sa는 변수이므로 int가 된다.
    System.out.println("05 : "+ic);
    
    long la=40L;
    long lb=50L;
    long lba=50+Integer.MAX_VALUE; //(int)+(int) 음수가 된다.
    long lbb=50L+Integer.MAX_VALUE; //(long+int) 양수가 된다.
    long lc=la+lb; //(long+long)
    System.out.println("06 : "+lba);
    System.out.println("07 : "+lbb);
    System.out.println("08 : "+lc);
    
    float fa=45.0f;
    float fb=46.67f;  //F가 없으면 long타입이 된다.
    // float fc =30.4; //int는 자동으로 float이 된다.
    float fd=30;
    float fe=fa+fb;
    
    double da=12;
    double db=45+Float.MAX_VALUE;
    double dc=da+db;
    System.out.println("09 : "+dc);
    
    System.out.println("10 : "+ "byte 범위:"+Byte.MIN_VALUE+"~"+Byte.MAX_VALUE);
    System.out.println("11 : "+ "short 범위:"+Short.MIN_VALUE+"~"+Short.MAX_VALUE);
    System.out.println("12 : "+ "int 범위:"+Integer.MIN_VALUE+"~"+Integer.MAX_VALUE);
    System.out.println("13 : "+ "long 범위:"+Long.MIN_VALUE+"~"+Long.MAX_VALUE);
    System.out.println("14 : "+ "float 범위:"+Float.MIN_VALUE+"~"+Float.MAX_VALUE);
    System.out.println("15 : "+ "double 범위:"+Double.MIN_VALUE+"~"+Double.MAX_VALUE);
  }
}
