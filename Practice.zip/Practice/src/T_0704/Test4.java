package T_0704;

import java.util.Calendar;

public class Test4 {
  public static void main(String[] args) {
    
    int a=20;
    long b=30000L;
    float c=34.98F;
    double d =234.234;
    char e='k';
    Calendar today= Calendar.getInstance();
    System.out.println("1:"+a+""+b+""+c+""+d+""+e); //불편
    System.out.printf("2:\\%% %d %d %f %f %c %n",a,b,c,d,e); //편리
    System.out.printf("3:%l$d %l$d %2$c\n",a,97);
    System.out.printf("4:%l$h %l$o %l$x\n",a);
    System.out.printf("5:%f %l$a %l$e %l$f %l$g\n",65.8734543537);
    System.out.printf("6:Today %l$tm %l$te,%l$tY %n", today);
    System.out.printf("7:Today %l$tm %l$td,%l$ty %n", today);
    System.out.printf("8:Today %l$th %l$tI,%l$ta %n", today);
    System.out.printf("9:123456789012345678901234567890\n");
    System.out.printf("10:%l$20f\n", 5678.3435453535);
    System.out.printf("11:%l$20.10f\n", 5678.3435453535);
    System.out.printf("12:%l$-20.10f\n", 5678.3435453535);
  } //argument_index$conversion  
}
