package Vendingmachine;

public class Threethousand implements DWaterV{

  @Override
  public void product1() {
    System.out.println("카페라떼");
    
  }

  @Override
  public void product2() {
    System.out.println("딸기라떼");
    
  }

  @Override
  public void product3() {
    System.out.println("망고주스");
    
  }

  @Override
  public void product4() {
    System.out.println("그린티라떼");
    
  }

  @Override
  public void product5() {
    System.out.println("카라멜마끼아또");
    
  }

  @Override
  public void titmsg() {
    System.out.println("**3,000원 음료수 제품 목록**");
    
  }

}
