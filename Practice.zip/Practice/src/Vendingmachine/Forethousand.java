package Vendingmachine;

public class Forethousand implements DWaterV {

  @Override
  public void product1() {
    System.out.println("솔의눈");
    
  }

  @Override
  public void product2() {
    System.out.println("콜드브루라떼");
    
  }

  @Override
  public void product3() {
    System.out.println("토레타");
    
  }

  @Override
  public void product4() {
    System.out.println("실론티");
    
  }

  @Override
  public void product5() {
    System.out.println("핫블루아메리카노");
    
  }

  @Override
  public void titmsg() {
    System.out.println("**4,000원 음료수 제품 목록**");
    
  }

}
