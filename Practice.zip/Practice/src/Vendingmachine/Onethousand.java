package Vendingmachine;

public class Onethousand implements DWaterV {

  @Override
  public void product1() {
    System.out.println("코카콜라 100mL");
    
  }

  @Override
  public void product2() {
    System.out.println("비락식혜 100mL");
    
  }

  @Override
  public void product3() {
    System.out.println("수정과 100mL");
    
  }

  @Override
  public void product4() {
    System.out.println("레스비 100mL");
    
  }

  @Override
  public void product5() {
    System.out.println("티오피 100mL");
    
  }

  @Override
  public void titmsg() {
    System.out.println("**1,000원 음료수 제품 목록**");
    
  }

}
