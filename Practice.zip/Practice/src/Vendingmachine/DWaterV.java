package Vendingmachine;

public interface DWaterV {

  void product1();
  void product2();
  void product3();
  void product4();
  void product5();
  void titmsg();
}
