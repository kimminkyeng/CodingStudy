package Vendingmachine;

public class VMRun {
  public static void main(String[] args) {
    DWaterV forethousand = new Forethousand();
    DWaterV threethousand = new Threethousand();
    DWaterV twothousand = new Twothousand();
    DWaterV onethousand = new Onethousand();
    
    DWaterV[] dWaterV = {forethousand,threethousand,twothousand,onethousand};
    
    for(int i=0;i<dWaterV.length;i++) {
      System.out.println("**음료수 자판기 제품목록**");
      dWaterV[i].titmsg();
      dWaterV[i].product1();
      dWaterV[i].product2();
      dWaterV[i].product3();
      dWaterV[i].product4();
      dWaterV[i].product5();
      System.out.println("============");
    }
  }
}
