package Vendingmachine;

public class Twothousand implements DWaterV {

  @Override
  public void product1() {
    System.out.println("코카콜라 1.5L");
    
  }

  @Override
  public void product2() {
    System.out.println("비락식혜 1.5L");
    
  }

  @Override
  public void product3() {
    System.out.println("수정과 1.5L");
    
  }

  @Override
  public void product4() {
    System.out.println("헛개차");
    
  }

  @Override
  public void product5() {
    System.out.println("옥수수수염차");
    
  }

  @Override
  public void titmsg() {
    System.out.println("**2,000원 음료수 제품 목록**");
    
  }

}
