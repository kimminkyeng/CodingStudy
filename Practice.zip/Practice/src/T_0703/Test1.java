package T_0703;

public class Test1 {
  public static void main(String[] args) {
    String str = "안녕하세요!! JAVA를 즐깁시다.";
       System.out.println(str);
  }
}
