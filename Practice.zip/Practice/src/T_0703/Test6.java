package T_0703;

public class Test6 {
  public static void main(String[] args) {
    System.out.println(Math.PI);
    System.out.println(Math.E);
    // 원의 넓이
    double r=10;
    double s=Math.PI*r*r;
    System.out.println("원의 넓이"+s);
  }
}
