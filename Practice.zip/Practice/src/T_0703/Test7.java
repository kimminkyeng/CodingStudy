package T_0703;

public class Test7 {
  public static void main(String[] args) {
    double r=10.0;
    double c=r*r*Math.PI;
    double d=Math.sqrt(2.4);
    double e=Math.pow(2,3);
    System.out.println(c);
    System.out.println(d);
    System.out.println(e);
  }
}
