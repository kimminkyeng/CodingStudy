package T_0703;


public class Test2 {
  public static void main(String[] args) {
/**
 * Created on 2005.8.25<br>
 * Java.util.Data를 이용해 하루 전과 하루 뒤를 구함<br>
 * @author hyoeun cho
 */
    /**
     * @param d 입력 다음 날을 출력하기 위한 입력 날
     * @return 하루 뒤를 출력
     */
//    public Date afterOneDay(Date d) {
      //d 기준 날짜를 입력한다.
//      long dd=d.getTime();
      //밀리세컨드*60초*60분*24시간==하루
//      return new Date(dd+1000*60*60*24);
    }
    /*    public Data setDate(int year,int month, int day) {
      //d 기준 날짜를 입력한다.
      long dd=d.getTime();
      //밀리세컨드*60초*60분*24시간==하루
      return new Date(dd+1000*60*60*24);
      Calendar cal=Calender.getInstance();
      cal.set(year,month-1,day);// 0~11까지 존재하기 때문에 -1
      return new Date(cal.getTimeInMillis());
    }
    */
  }
