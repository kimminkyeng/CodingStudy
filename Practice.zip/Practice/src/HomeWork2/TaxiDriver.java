package HomeWork2;

public class TaxiDriver extends Chef {
   void taxiDriverRun() {
    System.out.println("택시기사는 시내를 주행합니다.");
  }

}
