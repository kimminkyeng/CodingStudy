package HomeWork2;

public class Doctor extends TaxiDriver {
  void doctorRun() {
    System.out.println("의사는 치료를 합니다.");
  }
}
