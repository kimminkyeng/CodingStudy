package HomeWork2;

public class Firefighter extends Doctor {
  void firefighterRun() {
    System.out.println("소방관은 불을끕니다.");
  }
}
