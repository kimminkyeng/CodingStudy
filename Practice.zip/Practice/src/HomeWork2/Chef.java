package HomeWork2;

public class Chef {
  void chefRun() {
    System.out.println("요리사는 스파게티를 만듭니다.");
  }
}
