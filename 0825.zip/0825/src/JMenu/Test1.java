package JMenu;

import java.awt.MenuBar;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;

public class Test1 extends JFrame {
  JMenuBar menuBar; //프레임에 메뉴바 탑재
  JMenu fileMenu, helpMenu; // 메뉴바에 원하는 '주메뉴'를 올려준다.
  
  
  public Test1() {
    super("메뉴 연습");
    setSize(300, 300);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    menuBar = new JMenuBar();
    
    fileMenu = new JMenu("파일");
    helpMenu = new JMenu("도움말");
    
    menuBar.add(fileMenu);
    menuBar.add(helpMenu);
    
    //add(menuBar); <-이렇게 작성하면 안됨.
    setJMenuBar(menuBar); // 메뉴바에 주메뉴 올리기
    
    setVisible(true);
  }
  
  public static void main(String[] args) {
    new Test1();
  }
}
