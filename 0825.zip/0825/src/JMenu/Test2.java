package JMenu;

import java.awt.MenuBar;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

public class Test2 extends JFrame {
  JMenuBar menuBar; //프레임에 메뉴바 탑재
  JMenu fileMenu, helpMenu; // 메뉴바에 원하는 '주메뉴'를 올려준다.
  JMenuItem fileOpen, fileSave, fileNew, helpVersion, helpExit; //'주메뉴'에 등록시킬 '서브메뉴'.
  
  public Test2() {
    super("메뉴 연습");
    setSize(300, 300);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    menuBar = new JMenuBar();
    
    fileMenu = new JMenu("파일");
    helpMenu = new JMenu("도움말");
    
    // 주메뉴 '파일'에 서브메뉴 올리기
    fileOpen = new JMenuItem("불러오기");
    fileMenu.add(fileOpen);
    fileMenu.addSeparator();//구분자
    fileNew = new JMenuItem("새 파일");
    fileMenu.add(fileNew);   
    //fileMenu.add(new JMenuItem("새 파일"));
    // '새 파일 서브메뉴'에 단축키 설정하기(Ctrl + Alt + N)
    fileMenu.getItem(2).setAccelerator(KeyStroke.getKeyStroke('N' , InputEvent.CTRL_MASK^InputEvent.ALT_MASK));
    fileSave = new JMenuItem("저장하기");
    fileMenu.add(fileSave);
    
    // 주메뉴 '도움말'에 서브메뉴 올리기
    helpVersion = new JMenuItem("버전정보");
    helpExit = new JMenuItem("종료");
    helpMenu.add(helpVersion);
    helpMenu.addSeparator();
    helpMenu.add(helpExit);

    // 주메뉴를 메뉴바에 올리기
    menuBar.add(fileMenu);
    menuBar.add(helpMenu);
    
    //add(menuBar); <-이렇게 작성하면 안됨.
    setJMenuBar(menuBar); // 메뉴바에 주메뉴 올리기
    
    setVisible(true);
    
    helpExit.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        System.exit(0);
      }
    });
    
    helpVersion.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(null, "회원관리 v1.0");
      }
    });
    
    fileNew.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(null, "새 파일을 엽니다");
      }
    });
  }
  
  public static void main(String[] args) {
    new Test2();
  }
}
