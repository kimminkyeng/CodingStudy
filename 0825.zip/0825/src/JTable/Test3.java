package JTable;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Test3 extends JFrame {
  DefaultTableModel defaultTableModel;
  JTable jTable;
  JScrollPane jScrollPane;
  
  String[] colNames = {"상품코드","상품명","가격","회사명"};
  Object[][] rowData = {
      {"A01","초코파이",500,"오리온"},
      {"A02","몽셀",600,"롯데"},
      {"B02","칸쵸",1000,"롯데"},
      {"B03","새우깡",1500,"농심"},
      {"B04","양파링",1800,"농심"},
      {"A01","초코파이",500,"오리온"},
      {"A02","몽셀",600,"롯데"},
      {"B02","칸쵸",1000,"롯데"},
      {"B03","새우깡",1500,"농심"},
      {"B04","양파링",1800,"농심"}
  };
  
  public Test3() {
    super("JTable 연습3");
    setSize(400,300);
    setLocationRelativeTo(null); //창이 가운데에서 뜸
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//x버튼 누를때 종료한다.
    
    defaultTableModel = new DefaultTableModel(rowData,colNames);
    jTable = new JTable(defaultTableModel);
    jScrollPane = new JScrollPane(jTable);
    
    add(jScrollPane);
    
    
    setVisible(true);
  }
  
  
  public static void main(String[] args) {
    new Test3();
  }
}
