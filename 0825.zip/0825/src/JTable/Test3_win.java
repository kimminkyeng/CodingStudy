package JTable;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Test3_win extends JFrame {
  DefaultTableModel defaultTableModel;
  JTable jTable;
  JScrollPane jScrollPane;
  
  String[] colNames = {"상품코드","상품명","가격","회사명"};
  Object[][] rowData = {
      {"A01","초코파이",500,"오리온"},
      {"A02","몽셀",600,"롯데"},
      {"B02","칸쵸",1000,"롯데"},
      {"B03","새우깡",1500,"농심"},
      {"B04","양파링",1800,"농심"},
      {"A01","초코파이",500,"오리온"},
      {"A02","몽셀",600,"롯데"},
      {"B02","칸쵸",1000,"롯데"},
      {"B03","새우깡",1500,"농심"},
      {"B04","양파링",1800,"농심"}
  };
  private JTextField txtPco;
  private JTextField txtPna;
  private JTextField txtPrice;
  private JTextField txtOffice;
  
  public Test3_win() {
    super("JTable 연습3");
    setSize(496,352);
    setLocationRelativeTo(null); //창이 가운데에서 뜸
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//x버튼 누를때 종료한다.
    
    defaultTableModel = new DefaultTableModel(rowData,colNames);
    getContentPane().setLayout(null);
    jTable = new JTable(defaultTableModel);
    jScrollPane = new JScrollPane(jTable);
    jScrollPane.setBounds(0, 0, 480, 217);
    
    getContentPane().add(jScrollPane);
    
    JLabel lblNewLabel = new JLabel("상품코드");
    lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
    lblNewLabel.setBounds(50, 227, 57, 15);
    getContentPane().add(lblNewLabel);
    
    JLabel label = new JLabel("상품명");
    label.setHorizontalAlignment(SwingConstants.CENTER);
    label.setBounds(157, 227, 57, 15);
    getContentPane().add(label);
    
    JLabel label_1 = new JLabel("가격");
    label_1.setHorizontalAlignment(SwingConstants.CENTER);
    label_1.setBounds(264, 227, 57, 15);
    getContentPane().add(label_1);
    
    JLabel label_2 = new JLabel("회사명");
    label_2.setHorizontalAlignment(SwingConstants.CENTER);
    label_2.setBounds(371, 227, 57, 15);
    getContentPane().add(label_2);
    
    txtPco = new JTextField();
    txtPco.setBounds(33, 252, 78, 21);
    getContentPane().add(txtPco);
    txtPco.setColumns(10);
    
    txtPna = new JTextField();
    txtPna.setColumns(10);
    txtPna.setBounds(144, 252, 78, 21);
    getContentPane().add(txtPna);
    
    txtPrice = new JTextField();
    txtPrice.setColumns(10);
    txtPrice.setBounds(255, 252, 78, 21);
    getContentPane().add(txtPrice);
    
    txtOffice = new JTextField();
    txtOffice.setColumns(10);
    txtOffice.setBounds(366, 252, 78, 21);
    getContentPane().add(txtOffice);
    
    JButton btnInput = new JButton("추  가");
    btnInput.setBounds(47, 280, 97, 23);
    getContentPane().add(btnInput);
    
    JButton btnDelete = new JButton("삭  제");
    btnDelete.setBounds(191, 280, 97, 23);
    getContentPane().add(btnDelete);
    
    JButton btnExit = new JButton("종  료");
    btnExit.setBounds(335, 280, 97, 23);
    getContentPane().add(btnExit);
    
    
    setVisible(true);
    
    // 자료 추가하기. 다시 디자인가서 '추가' 버튼 더블클릭하면 망가져서 안됨.
    btnInput.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        String[] str = new String[4];
        str[0] = txtPco.getText();
        str[1] = txtPna.getText();
        str[2] = txtPrice.getText();
        str[3] = txtOffice.getText();
        
        if(str[0].equals("")) {
          JOptionPane.showMessageDialog(null, "상품코드를 입력하세요!");
          txtPco.requestFocus();
        }
        else if(str[1].equals("")) {
          JOptionPane.showMessageDialog(null, "상품명을 입력하세요!");
          txtPna.requestFocus();
        }
        else if(str[2].equals("")) {
          JOptionPane.showMessageDialog(null, "상품가격을 입력하세요!");
          txtPrice.requestFocus();
        }
        else if(str[3].equals("")) {
          JOptionPane.showMessageDialog(null, "제조회사를 입력하세요!");
          txtOffice.requestFocus();
        }
        else {
          defaultTableModel.addRow(str);
          JOptionPane.showMessageDialog(null, "자료가 삽입되었습니다.");
          
          txtPco.setText("");
          txtPna.setText("");
          txtPrice.setText("");
          txtOffice.setText("");
        }
      }
    });
    // 자료 삭제하기. 다시 디자인가서 '삭제' 버튼 더블클릭하면 망가져서 안됨.
    btnDelete.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if(jTable.getSelectedRow() == -1) {
          JOptionPane.showMessageDialog(null, "삭제할 행을 선택하세요.");
          return;
        }
        else {
          int res = JOptionPane.showConfirmDialog(null, "정말로 삭제 하시겠습니까?","삭제창",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
          if(res == JOptionPane.YES_OPTION) {
            defaultTableModel.removeRow(jTable.getSelectedRow());
            JOptionPane.showMessageDialog(null, "삭제 되었습니다!");
          }
          else if(res == JOptionPane.NO_OPTION) {
            JOptionPane.showMessageDialog(null, "삭제 취소!");
          }
          else {
            JOptionPane.showMessageDialog(null, "삭제 취소!"); //다른 것에서도 삭제 취소.
          }
        }
      }
    });
    // 자료 종료하기. 다시 디자인가서 '종료' 버튼 더블클릭하면 망가져서 안됨.
    btnExit.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(null, "수고하셨습니다!!");
        System.exit(0);
      }
    });
  }
  
  
  public static void main(String[] args) {
    new Test3_win();
  }
}
