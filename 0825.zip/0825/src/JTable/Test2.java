package JTable;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Test2 extends JFrame {
  
  public Test2() {
    super("JTable 연습2");
    setSize(400, 300);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    //JTable생성 (데이터(2차원배열), 열이름) : 데이터는 2차원배열, 열이름은 1차원배열
      //열제목
    String[] colNames = {"상품코드","상품명","가격","회사명"}; //열이름
    
      //행데이터(2차원배열로)
    Object[][] rowData = {
        {"A01","초코파이",500,"오리온"},
        {"A02","몽셀",600,"롯데"},
        {"B02","칸쵸",1000,"롯데"},
        {"B03","새우깡",1500,"농심"},
        {"B04","양파링",1800,"농심"},
        {"A01","초코파이",500,"오리온"},
        {"A02","몽셀",600,"롯데"},
        {"B02","칸쵸",1000,"롯데"},
        {"B03","새우깡",1500,"농심"},
        {"B04","양파링",1800,"농심"},
    };
    // 앞에서 준비된 자료를 DefaultTableModel 생성시 넣어준다.
    DefaultTableModel defaultTableModel = new DefaultTableModel(rowData, colNames);
    
    
    JTable jTable = new JTable(defaultTableModel);
    // 생성된 JTable을 JScrollPane에 올려준다.
    JScrollPane jScrollPane = new JScrollPane(jTable);
    
    // 테이블 수정(편집, 삭제) 작업
    // 한개의 자료 추가(삽입)
    Object[] imsiObject = {"B05","바나나우유",1500,"빙그레"};
    defaultTableModel.addRow(imsiObject);
    
    //행과 열의 개수
    System.out.println("행의 개수 : " + defaultTableModel.getRowCount());
    System.out.println("열의 개수 : " + defaultTableModel.getColumnCount());
    
    //필드명 출력(1열)
    System.out.println("1열 필드명 : " + defaultTableModel.getColumnName(0));

    //특정위치의 값 가져오기(4행 3열의 값은?)
    System.out.println("4행 3열 : " + defaultTableModel.getValueAt(3, 2));
    
    //특정위치의 값 가져오기(4행 3열의 값을 2000으로 변경하시오)
    defaultTableModel.setValueAt("2000", 3, 2);
    
    //1행(0번 인덱스행)의 자료를 지우자
    defaultTableModel.removeRow(0);
    
    //특정 행을 선택하기
    jTable.setRowSelectionInterval(1, 2); //인덱스 1행(즉 2행)부터 3개행 선택
    
    add(jScrollPane);
    
    setVisible(true);
  }
  
  public static void main(String[] args) {
    new Test2();
  }
}
