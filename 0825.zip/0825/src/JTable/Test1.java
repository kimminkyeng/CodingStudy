package JTable;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class Test1 extends JFrame {
  
  public Test1() {
    super("JTable 연습1");
    setSize(400, 300);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    //JTable생성 (데이터(2차원배열), 열이름) : 데이터는 2차원배열, 열이름은 1차원배열
      //열제목
    String[] colNames = {"상품코드","상품명","가격","회사명"}; //열이름
    
      //행데이터(2차원배열로)
    Object[][] rowData = {
        {"A01","초코파이",500,"오리온"},
        {"A02","몽셀",600,"롯데"},
        {"B02","칸쵸",1000,"롯데"},
        {"B03","새우깡",1500,"농심"},
        {"B04","양파링",1800,"농심"},
        {"A01","초코파이",500,"오리온"},
        {"A02","몽셀",600,"롯데"},
        {"B02","칸쵸",1000,"롯데"},
        {"B03","새우깡",1500,"농심"},
        {"B04","양파링",1800,"농심"},
        {"A01","초코파이",500,"오리온"},
        {"A02","몽셀",600,"롯데"},
        {"B02","칸쵸",1000,"롯데"},
        {"B03","새우깡",1500,"농심"},
        {"B04","양파링",1800,"농심"},
        {"A01","초코파이",500,"오리온"},
        {"A02","몽셀",600,"롯데"},
        {"B02","칸쵸",1000,"롯데"},
        {"B03","새우깡",1500,"농심"},
        {"B04","양파링",1800,"농심"}
    };
    // 앞에서 준비된 자료를 JTable 생성시 넣어준다.
    JTable jTable = new JTable(rowData, colNames);
    // 생성된 JTable을 JScrollPane에 올려준다.
    JScrollPane jScrollPane = new JScrollPane(jTable);
    
    add(jScrollPane);
    
    setVisible(true);
  }
  
  public static void main(String[] args) {
    new Test1();
  }
}
