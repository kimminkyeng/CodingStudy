package t1_Array;

public class T2_BookRun {
  public static void main(String[] args) {
    // 책의 정보를 저장하기 위한 객체 생성
    T2_Book vo = new T2_Book(bookName, author);
  }
}
