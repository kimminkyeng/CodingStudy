package t1_awt;

import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

// 폼테크(로그인창 만들기)
public class Test19 extends Frame {
  Panel pn1, pn2, pn2_1, pn2_2, pn3;
  Label lbl1 , lblId, lblPwd, lblResult;
  TextField txtId, txtPwd;
  Button btnLogin, btnClear, btnExit;
  
  public Test19() {
    super("로그인 창");
    setVisible(true);
    setLayout(new GridLayout(4,1));
    setBounds(300, 250, 400, 300);
    
    pn1 = new Panel();
    lbl1 = new Label("회원 인증");
    pn1.add(lbl1);
    
    pn2 = new Panel();
    pn2.setLayout(new GridLayout(2, 1));  
    
    lblId = new Label("아이디 : ");
    //lblId.setAlignment(Label.LEFT);
    txtId = new TextField(10);
    lblPwd = new Label("비밀번호 : ");
    //lblPwd.setAlignment(Label.LEFT);
    txtPwd = new TextField(10);
    txtPwd.setEchoChar('*');
    
    pn2_1 = new Panel();
    pn2_1.setLayout(new FlowLayout());
    pn2_2 = new Panel();
    pn2_2.setLayout(new FlowLayout());
    
    pn2_1.add(lblId);
    pn2_1.add(txtId);
    pn2_2.add(lblPwd);
    pn2_2.add(txtPwd);
    
    pn2.add(pn2_1);
    pn2.add(pn2_2);
    
    pn3 = new Panel();
    btnLogin = new Button("로그인");
    btnClear = new Button("다시입력");
    btnExit = new Button("종료");
    
    pn3.add(btnLogin);
    pn3.add(btnClear);
    pn3.add(btnExit);
    
    lblResult = new Label("-결 과 창-");
    lblResult.setAlignment(Label.CENTER);
    
    add(pn1);
    add(pn2);
    add(pn3);
    add(lblResult);
    
    btnLogin.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        String data = "";
        if(txtId.getText().equals("") || txtPwd.getText().equals("")) {
          data = "아이디와 비밀번호를 입력하세요..";
        }
        else {
          data = "아이디 : " + txtId.getText() + " , 비밀번호 : " + txtPwd.getText();
        }
        lblResult.setText(data);
      }
    });
    
    btnClear.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        //System.out.println("clear");
        txtId.setText("");
        txtPwd.setText("");
        lblResult.setText("-결 과 창-");
      }
    });
    
    btnExit.addActionListener(new ActionListener() {
      
      @Override
      public void actionPerformed(ActionEvent e) {
       System.exit(0);
      }
    });
    
    addWindowListener(new WindowAdapter() {
      @Override
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
  }
  
  public static void main(String[] args) {
    new Test19();
    
  }
}
