package t1_awt;

import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Test17 extends Frame {
  Panel pn;
  Label lbl;
  
  public Test17() {
    super("마우스 클릭 이벤트");
    setVisible(true);
    setBounds(300, 250, 300, 300);

    pn = new Panel();
    pn.setLayout(null);
    
    lbl = new Label("이곳에 마우스 좌표가 출력됩니다.");
    lbl.setBounds(20, 20, 190, 50);
    
    pn.add(lbl);
    add(pn);
    
    pn.addMouseListener(new MouseAdapter() {
      @Override
      public void mouseClicked(MouseEvent e) {
        Integer x = e.getX();
        Integer y = e.getY();
        String position = "클릭좌표- x:" + x.toString() + " , y:" + y.toString();
        lbl.setText(position);
      }
   });
      
    
    addWindowListener(new WindowAdapter() {
      @Override
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
  }
  
  public static void main(String[] args) {
    new Test17();
  }
}
