package t1_awt;

import java.awt.BorderLayout;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Frame;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Test14 extends Frame implements ItemListener{
  Panel pn1;
  Checkbox gender1, gender2;
  CheckboxGroup group;
  TextArea ta;
  
  public Test14() {
    super("컴포넌트(라디오버튼) 연습");
    setVisible(true);
    setLayout(new BorderLayout());
    setBounds(300,250,300,300);
    
    pn1 = new Panel();  
    
    group = new CheckboxGroup();
    gender1= new Checkbox("남자",group,true);
    gender2= new Checkbox("여자",group,false);
    
    pn1.add(gender1);
    pn1.add(gender2);
    
    //add(pn1); 프레임에다가 pn1에 남자 여자 자료 올린것.
    
    ta = new TextArea();
    
    add(pn1, BorderLayout.NORTH);
    add(ta, BorderLayout.CENTER);
    
    gender1.addItemListener(this);
    gender2.addItemListener(this);
    
    addWindowListener(new WindowAdapter() {
      @Override
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
  }
  
  public static void main(String[] args) {
   new Test14(); 
    }

  @Override
  public void itemStateChanged(ItemEvent e) {
    String gender = e.paramString();
    if(gender.contains("남자")) {
      ta.append("남자\n");
    }
    else ta.append("여자\n");
  }
}