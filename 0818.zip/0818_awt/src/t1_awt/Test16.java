package t1_awt;

import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


public class Test16 extends Frame {
  Panel pn;
  Label lbl;
  
  public Test16() {
    super("마우스 좌표 출력");
    setVisible(true);
    setBounds(300, 250, 300, 300);
    
    pn = new Panel();
    lbl = new Label("이곳에 좌표가 출력됩니다.");
    
    pn.add(lbl);
    
    add(pn);
    
    pn.addMouseMotionListener(new MouseMotionListener() {
      
      @Override
      public void mouseMoved(MouseEvent e) {
        Integer x = e.getX();
        Integer y = e.getY();
        String position = "X : " + x.toString() + " , Y : " + y.toString();
        lbl.setText(position);
      }
      
      @Override
      public void mouseDragged(MouseEvent e) {}
    });
    
    addWindowListener(new WindowAdapter() {
      @Override
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
  }
  public static void main(String[] args) {
    new Test16(); 
}
}
