package t1_awt;

import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

//일반키값과 기능키값 출력
public class Test18 extends Frame{
  Panel pn;
  Label lbl1, lbl2;
  
  public Test18 () {
    super("키값(일반키/기능키)연습");
    setVisible(true);
    setBounds(300, 250, 300, 300);
    
    pn = new Panel();
    pn.setLayout(null);
    
    lbl1 = new Label("기능키: ");
    lbl1.setBounds(20, 20, 150, 50);
    lbl2 = new Label("일반키: ");
    lbl2.setBounds(20, 20, 150, 50);
    
    pn.add(lbl1);
    pn.add(lbl2);
    
    add(pn);
    
    
    pn.requestFocus(); //초점맞추기.
    
    pn.addKeyListener(new KeyAdapter() {
      @Override
      public void keyPressed(KeyEvent e) {
        String str = "";
        char cKey = e.getKeyChar();
        
      //e.CHAR_UNDEFINED <- 특수키. e.getKeyCode()<- 숫자로 코드로 나옴. e.getKeyText(e.getKeyCode());<- 문자와 숫자 포함해서 출력가능.
        if(cKey == e.CHAR_UNDEFINED) {
          str = "기능키 : " + e.getKeyText(e.getKeyCode());
          lbl1.setText(str);
        }
        else {
          str = "일반키 : " + cKey;
          lbl2.setText(str);
        }
      }
    });
    
    addWindowListener(new WindowAdapter() {
      @Override
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
  }
  
  public static void main(String[] args) {
    new Test18();
  }
}
