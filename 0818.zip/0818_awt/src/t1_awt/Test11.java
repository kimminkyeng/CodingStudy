package t1_awt;

import java.awt.Frame;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

//키보드 이벤트 연습
public class Test11 extends Frame implements WindowListener, KeyListener {
  public Test11() {
    super("키보드 이벤트 연습");
    setVisible(true);
    setBounds(300, 250, 300, 300);
    
    addKeyListener(this);
    addWindowListener(this);
  }
  public static void main(String[] args) {
    new Test11();
      
  }
  @Override
  public void keyPressed(KeyEvent arg0) {
    //System.out.println("키보드를 누르고 있군요...");
    System.out.println("입력된 키값은 무엇인가요? " + arg0.getKeyChar());
  }
  @Override
  public void keyReleased(KeyEvent arg0) {
    //System.out.println("키보드를 눌렀다가 놓으셨군요...");
    }
  @Override
  public void keyTyped(KeyEvent arg0) {
    //System.out.println("키보드를 입력중이시군요...");
    }
  @Override
  public void windowActivated(WindowEvent e) {}
  @Override
  public void windowClosed(WindowEvent e) {}
  @Override
  public void windowClosing(WindowEvent e) {
    System.exit(0);
  }
  @Override
  public void windowDeactivated(WindowEvent e) {}
  @Override
  public void windowDeiconified(WindowEvent e) {}
  @Override
  public void windowIconified(WindowEvent e) {}
  @Override
  public void windowOpened(WindowEvent e) {}
}
