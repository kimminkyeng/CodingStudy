package t1_awt;

import java.awt.Choice;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.List;
import java.awt.Panel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Test20 extends Frame {
  Panel pn1, pn2;
  Choice choJob; //콤보상자
  List card; //리스트박스
  
  public Test20() {
    super("콤보상자/리스트박스 연습");
    setVisible(true);
    setBounds(300, 250, 300, 400);
    setLayout(new GridLayout(2,1));
    
    pn1 = new Panel();
    choJob = new Choice();
    choJob.add("학생");
    choJob.add("군인");
    choJob.add("회사원");
    choJob.add("공무원");
    choJob.add("의사");
    choJob.add("프리랜서");
    choJob.add("기타");
    
    pn1.add(choJob);
    
    pn2 = new Panel();
    card = new List(8,true); // true는 리스트에서 다중선택이 가능함. false는 기본값(단일선택).
    card.add("엘지카드");
    card.add("삼성카드");
    card.add("농협카드");
    card.add("롯데카드");
    card.add("비자카드");
    card.add("국민카드");
    card.add("신한카드");
    card.add("신협카드");
    card.add("하나카드");
    card.add("한화카드");
    
    pn2.add(card);
    
    add(pn1);
    add(pn2);
    
    addWindowListener(new WindowAdapter() {
      @Override
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
  }
  
  public static void main(String[] args) {
   new Test20();  
  }
}
