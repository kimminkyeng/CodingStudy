package t1_awt;

import java.awt.Button;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

//수동레이아웃 연습
public class Test9_0 extends Frame implements WindowListener, ActionListener{
  Button btn1, btn2, btn3, btnExit;
  
  public Test9_0() {
    super("수동레이아웃");
    setLayout(null);//다른 레이아웃을 쓰지 않을꺼야.
    setVisible(true);
    setBounds(300, 250, 300, 300);
    
    btn1 = new Button("첫번째");
    btn2 = new Button("두번째");
    btn3 = new Button("세번째");
    btnExit = new Button("종료");
    
    int x=50, y=80;
    
    btn1.setBounds(x, y, 150, 30);
    btn2.setBounds(x, y+40, 150, 30);
    btn3.setBounds(x, y+80, 150, 30);
    btnExit.setBounds(x, y+120, 150, 30);
    
    add(btn1);
    add(btn2);
    add(btn3);
    add(btnExit);
    
    btnExit.addActionListener(this);
    addWindowListener(this);
  }
  
  public static void main(String[] args) {
    new Test9_0();
  }

  @Override
  public void actionPerformed(ActionEvent e) {System.exit(0);}
  @Override
  public void windowActivated(WindowEvent e) {}
  @Override
  public void windowClosed(WindowEvent e) {}
  @Override
  public void windowClosing(WindowEvent e) {System.exit(0);}
  @Override
  public void windowDeactivated(WindowEvent e) {}
  @Override
  public void windowDeiconified(WindowEvent e) {}
  @Override
  public void windowIconified(WindowEvent e) {}
  @Override
  public void windowOpened(WindowEvent e) {}
}
