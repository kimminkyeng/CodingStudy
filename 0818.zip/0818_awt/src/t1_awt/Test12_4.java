package t1_awt;

import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

// 레이아웃(프레임에 패널을 올려보자) - 응용연습
public class Test12_4 extends Frame implements WindowListener, ActionListener{
  Panel pn1, pn1C, pn2, pn3, pn3r;
  Label lbl1, lbl1c1, lbl1c2, lbl1r, lbl2, lbl3Top, lbl3Bottom;
  Button btn1, btnExit;
  
  public Test12_4() {
    super("패널 연습");
    setVisible(true);
    setBounds(300, 250, 400, 400);
    setLayout(new GridLayout(3,1));
    
    // 첫번째 행의 pn1을 올려보자(pn1에는 lbl1을 올린다.)
    pn1 = new Panel(); //단지 올려주기 위한 보드판임.
    pn1.setLayout(new GridLayout(1, 3));
    pn1.setBackground(Color.CYAN);
    pn1.setForeground(Color.BLACK);
    lbl1 = new Label("구분");
    lbl1.setAlignment(Label.CENTER);
    pn1.add(lbl1);
    
    //첫번째 행의 중간열(pn1C)
    pn1C = new Panel();
    pn1C.setLayout(new GridLayout(2,1));
    lbl1c1 = new Label("아이디");
    lbl1c1.setAlignment(Label.CENTER);
    lbl1c1.setBackground(Color.BLACK);
    lbl1c1.setForeground(Color.WHITE);
    lbl1c2 = new Label("비밀번호");
    lbl1c2.setAlignment(Label.CENTER);
    lbl1c2.setBackground(Color.PINK);
    lbl1c2.setForeground(Color.WHITE);
    pn1C.add(lbl1c1);
    pn1C.add(lbl1c2);
    pn1.add(pn1C);
    
    //첫번째 행의 3열 오른쪽
    lbl1r = new Label("확인");
    lbl1r.setAlignment(Label.CENTER);
    pn1.add(lbl1r);
    
    //두번째 행
    pn2 = new Panel(); //단지 올려주기 위한 보드판임.
    lbl2 = new Label("두번째 패널입니다.");
    btnExit = new Button("종료");
    pn2.setBackground(Color.RED);
    pn2.setForeground(Color.black);
    pn2.add(lbl2);
    pn2.add(btnExit);
    
    //세번째 행
    pn3 = new Panel(); //단지 올려주기 위한 보드판임.
    pn3.setLayout(new GridLayout(1,2)); //1행 2열로 나누기 작업.
    pn3.setBackground(Color.GREEN);
    btn1 = new Button("세번째 패널입니다.");
    pn3.add(btn1);
    
    //세번째 행의 오른쪽
    pn3r = new Panel();
    pn3r.setLayout(new GridLayout(2, 1));
    pn3r.setBackground(Color.gray);
    pn3r.setForeground(Color.WHITE);
    lbl3Top = new Label("3단 위쪽");
    lbl3Top.setAlignment(Label.CENTER);
    lbl3Top.setBackground(Color.BLACK);
    lbl3Top.setForeground(Color.WHITE);
    lbl3Bottom = new Label("3단 아래쪽");
    lbl3Bottom.setAlignment(Label.CENTER);
    lbl3Bottom.setBackground(Color.GREEN);
    lbl3Bottom.setForeground(Color.RED);
    pn3r.add(lbl3Top);
    pn3r.add(lbl3Bottom);
    
    pn3.add(pn3r);
    
    add(pn1);
    add(pn2);
    add(pn3);
    
    
    btnExit.addActionListener(this);
    addWindowListener(this);
  }
  
  public static void main(String[] args) {
    new Test12_4();
  }

  @Override
  public void actionPerformed(ActionEvent e) {
    System.exit(0);
  }

  @Override
  public void windowActivated(WindowEvent e) {}

  @Override
  public void windowClosed(WindowEvent e) {}

  @Override
  public void windowClosing(WindowEvent e) {
    System.exit(0);
  }

  @Override
  public void windowDeactivated(WindowEvent e) {}

  @Override
  public void windowDeiconified(WindowEvent e) {}

  @Override
  public void windowIconified(WindowEvent e) {}

  @Override
  public void windowOpened(WindowEvent e) {}
}
