package t1_awt;

import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

//코드를 넣어 보자
//어뎁터를 이용한 종료...(익명클래스 이용)
public class Test13_4 extends Frame  {
  Button btnPlay, btnClose;

  public Test13_4 () {
    super("익명클래스를 이용한 방법");
    setVisible(true);
    setLayout(new FlowLayout());
    setBounds(300, 250, 300, 300);
    
    btnPlay = new Button("Play");
    btnClose = new Button("Close");
    
    add(btnPlay);
    add(btnClose);
    
    //익명클래스 호출
    btnPlay.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        Button btnTxt = (Button)e.getSource(); //Button타입으로 강제 형변환.
        if(btnTxt.getLabel().equals("Play")) {
          btnTxt.setLabel("Stop");
        }
        else {
          btnTxt.setLabel("Play");
        }
      }
    });
    
    btnClose.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        System.exit(0);
      }
    });
    
    //익명 클래스를 이용한 윈도우 종료.
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
     }
    });//()에 익명클래스 만들기 WindowAdapter().
  }
  
  public static void main(String[] args) {
    new Test13_4();
  }
}
