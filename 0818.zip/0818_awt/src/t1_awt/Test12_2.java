package t1_awt;

import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

// 레이아웃(프레임에 패널을 올려보자) - 색상넣어서 구별 연습
public class Test12_2 extends Frame implements WindowListener, ActionListener{
  Panel pn1, pn2, pn3;
  Label lbl1, lbl2;
  Button btn1, btnExit;
  
  public Test12_2() {
    super("패널 연습");
    setVisible(true);
    setLayout(new GridLayout(3,1));
    setBounds(300, 250, 300, 300);
    
    // 첫번째 행의 pn1을 올려보자(pn1에는 lbl1을 올린다.)
    pn1 = new Panel(); //단지 올려주기 위한 보드판임.
    lbl1 = new Label("첫번째 패널입니다.");
    pn1.setBackground(Color.CYAN);
    pn1.setForeground(Color.white);
    pn1.add(lbl1);
    
    pn2 = new Panel(); //단지 올려주기 위한 보드판임.
    lbl2 = new Label("두번째 패널입니다.");
    btnExit = new Button("종료");
    pn2.setBackground(Color.RED);
    pn2.setForeground(Color.black);
    pn2.add(lbl2);
    pn2.add(btnExit);
    
    pn3 = new Panel(); //단지 올려주기 위한 보드판임.
    btn1 = new Button("세번째 패널입니다.");
    pn3.setBackground(Color.GREEN);
    pn3.add(btn1);
    
    add(pn1);
    add(pn2);
    add(pn3);
    btnExit.addActionListener(this);
    addWindowListener(this);
  }
  
  public static void main(String[] args) {
    new Test12_2();
  }

  @Override
  public void actionPerformed(ActionEvent e) {
    System.exit(0);
  }

  @Override
  public void windowActivated(WindowEvent e) {}

  @Override
  public void windowClosed(WindowEvent e) {}

  @Override
  public void windowClosing(WindowEvent e) {
    System.exit(0);
  }

  @Override
  public void windowDeactivated(WindowEvent e) {}

  @Override
  public void windowDeiconified(WindowEvent e) {}

  @Override
  public void windowIconified(WindowEvent e) {}

  @Override
  public void windowOpened(WindowEvent e) {}
}
