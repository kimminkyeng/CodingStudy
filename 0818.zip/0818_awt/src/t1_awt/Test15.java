package t1_awt;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Checkbox;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class Test15 extends Frame{
  Panel pn1;
  Label lbl1, lbl2;
  Checkbox chk1, chk2, chk3, chk4;
  TextArea ta;
  Button btnExit;
  String selectTa = "";
  
  public Test15 () {
  super("체크박스 연습");
    setVisible(true);
    setLayout(new BorderLayout());
    setBounds(300, 250, 300, 300);
    
    pn1 = new Panel();
    pn1.setLayout(new FlowLayout());
    
    lbl1 = new Label("취미를 선택하세요. ");
    chk1 = new Checkbox("등산");
    chk2 = new Checkbox("낚시");
    chk3 = new Checkbox("독서");
    chk4 = new Checkbox("영화감상");
    btnExit = new Button("종료");
    
    
    pn1.add(lbl1);
    pn1.add(chk1);
    pn1.add(chk2);
    pn1.add(chk3);
    pn1.add(chk4);
    pn1.add(btnExit);
    
    ta = new TextArea();
    
    lbl2 = new Label("선택된 결과는?");
    lbl2.setAlignment(Label.CENTER);
    
    add(pn1, BorderLayout.NORTH);
    add(ta, BorderLayout.CENTER);
    add(lbl2, BorderLayout.SOUTH);
    
    btnExit.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        //ta.setText(""); 선택하면 지워지는것
        System.exit(0);
      }
    });
    
    chk1.addItemListener(new ItemListener() {
      @Override
      public void itemStateChanged(ItemEvent e) {
        //삼항연산자
        lbl2.setText(e.getStateChange() == 1 ? "등산이 선택되었습니다." : "등산이 취소되었습니다.");
        selectTa = e.getItem().toString(); 
        ta.append(selectTa + "\n");
      }
    });
    
    chk2.addItemListener(new ItemListener() {
      @Override
      public void itemStateChanged(ItemEvent e) {
        //삼항연산자
        lbl2.setText(e.getStateChange() == 1 ? "낚시가 선택되었습니다." : "낚시가 취소되었습니다.");
        selectTa = e.getItem().toString(); 
        ta.append(selectTa + "\n");
      }
    });
    
    chk3.addItemListener(new ItemListener() {
      @Override
      public void itemStateChanged(ItemEvent e) {
        //삼항연산자
        lbl2.setText(e.getStateChange() == 1 ? "독서가 선택되었습니다." : "독서가 취소되었습니다.");
        selectTa = e.getItem().toString(); 
        ta.append(selectTa + "\n");
      }
    });
    
    chk4.addItemListener(new ItemListener() {
      @Override
      public void itemStateChanged(ItemEvent e) {
        //삼항연산자
        lbl2.setText(e.getStateChange() == 1 ? "영화감상이 선택되었습니다." : "영화감상이 취소되었습니다.");
        selectTa = e.getItem().toString(); 
        ta.append(selectTa + "\n");
      }
    });
    
    addWindowListener(new WindowAdapter() {
      @Override
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
  }
  
  public static void main(String[] args) {
    new Test15();
  }
}