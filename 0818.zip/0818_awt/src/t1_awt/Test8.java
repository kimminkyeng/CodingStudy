package t1_awt;

import java.awt.Button;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

// GridLayout 학습
public class Test8 extends Frame implements WindowListener, ActionListener {
  Button btn1, btn2, btn3, btn4, btn5;
  Label lbl1;
  
  public Test8() {
    super("GridLayout 연습");
    setVisible(true);
    setBounds(300, 250, 300, 300);
    setLayout(new GridLayout(2,3));
    
    btn1 = new Button("첫번째(종료)");
    btn2 = new Button("두번째");
    btn3 = new Button("세번째");
    btn4 = new Button("네번째");
    btn5 = new Button("다섯번째");
    
    lbl1 = new Label("GridLayout");
    lbl1.setAlignment(Label.CENTER);
    
    
    this.add(btn1);
    add(btn2);
    add(btn3);
    add(btn4);
    add(lbl1);
    add(btn5); //서로 줄을 바꾸면 출력되는 위치도 바뀐다.
    
    addWindowListener(this);
  }

  public static void main(String[] args) {
    new Test8();
  }

  @Override
  public void actionPerformed(ActionEvent e) {}
  @Override
  public void windowActivated(WindowEvent e) {}
  @Override
  public void windowClosed(WindowEvent e) {}
  @Override
  public void windowClosing(WindowEvent e) {
    System.exit(0);
  }
  @Override
  public void windowDeactivated(WindowEvent e) {}
  @Override
  public void windowDeiconified(WindowEvent e) {}
  @Override
  public void windowIconified(WindowEvent e) {}
  @Override
  public void windowOpened(WindowEvent e) {}
}
