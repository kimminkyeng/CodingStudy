package t1_awt;

import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

//코드를 넣어 보자
//어뎁터를 이용한 종료...(익명클래스 이용)
public class Test13_2 extends Frame  {

  public Test13_2 () {
    super("익명클래스를 이용한 방법");
    setVisible(true);
    setBounds(300, 250, 300, 300);
    
    //익명 클래스를 이용한 윈도우 종료.
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
     }
    });//()에 익명클래스 만들기 WindowAdapter().
  }
  
  public static void main(String[] args) {
    new Test13_2();
  }
}
