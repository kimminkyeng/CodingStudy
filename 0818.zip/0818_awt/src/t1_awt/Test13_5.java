package t1_awt;

import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

//코드를 넣어 보자
//어뎁터를 이용한 종료...(익명클래스 이용)
public class Test13_5 extends Frame implements ActionListener {
  Button btnPlay, btnClose;

  public Test13_5 () {
    super("익명클래스를 이용한 방법");
    setVisible(true);
    setLayout(new FlowLayout());
    setBounds(300, 250, 300, 300);
    
    btnPlay = new Button("Play");
    btnClose = new Button("Close");
    
    add(btnPlay);
    add(btnClose);
    
   btnPlay.addActionListener(this);
   btnClose.addActionListener(this);
    
    //익명 클래스를 이용한 윈도우 종료.
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
     }
    });//()에 익명클래스 만들기 WindowAdapter().
  }
  
  public static void main(String[] args) {
    new Test13_5();
  }

  @Override
  public void actionPerformed(ActionEvent e) {
   Button btnText = (Button) e.getSource();
    if(btnText.getLabel().equals("play")) {
      btnText.setLabel("Stop");
    }
    else if(btnText.getLabel().equals("Close")) {
    }
    else {
      btnText.setLabel("Play");
    }
  }
}
