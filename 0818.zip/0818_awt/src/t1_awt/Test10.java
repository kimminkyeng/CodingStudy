package t1_awt;

import java.awt.Frame;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

// 마우스 이벤트
public class Test10 extends Frame implements WindowListener, MouseListener {
  public Test10 () {
    super("마우스 이벤트 연습");
    setVisible(true);
    setBounds(300, 250, 300, 300);
    
    addMouseListener(this);
    addWindowListener(this);
  }
  
  public static void main(String[] args) {
    new Test10();
  }

  @Override
  public void windowActivated(WindowEvent e) {}

  @Override
  public void windowClosed(WindowEvent e) {}

  @Override
  public void windowClosing(WindowEvent e) {
    System.exit(0);}

  @Override
  public void windowDeactivated(WindowEvent e) {}

  @Override
  public void windowDeiconified(WindowEvent e) {}

  @Override
  public void windowIconified(WindowEvent e) {}

  @Override
  public void windowOpened(WindowEvent e) {}

  @Override
  public void mouseClicked(MouseEvent arg0) {
    System.out.println("마우스를 클릭했습니다.");}

  @Override
  public void mouseEntered(MouseEvent arg0) {
    System.out.println("마우스가 프레임 안으로 진입합니다.");
  }

  @Override
  public void mouseExited(MouseEvent arg0) {
    System.out.println("마우스가 프레임 밖으로 나가고 있습니다.");
  }

  @Override
  public void mousePressed(MouseEvent arg0) {
    System.out.println("마우스 왼쪽 버튼을 눌렀군요.");
  } //마우스를 누르는 순간

  @Override
  public void mouseReleased(MouseEvent arg0) {
    System.out.println("마우스 왼쪽 버튼을 눌렀다가 놓았군요.");
  } //마우스를 떠나는 순간
}
