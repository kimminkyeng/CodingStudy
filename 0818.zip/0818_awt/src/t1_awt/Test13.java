package t1_awt;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

//코드를 넣어 보자
public class Test13 extends Frame implements WindowListener, ActionListener {
  Button btnCenter;
  
  public Test13 () {
    super("인터페이스를 이용한 방법");
    setVisible(true);
    setBounds(300, 250, 300, 300);
    setLayout(new BorderLayout());
    
    btnCenter = new Button("종료");
    
    //add(btnCenter,"Center");
    add(btnCenter, BorderLayout.CENTER); //위 21번줄이랑 같은 결과임.
    
    btnCenter.addActionListener(this);
    addWindowListener(this);
  }
  
  public static void main(String[] args) {
    new Test13();
  }

  @Override
  public void windowActivated(WindowEvent arg0) {}

  @Override
  public void windowClosed(WindowEvent arg0) {}

  @Override
  public void windowClosing(WindowEvent arg0) {
    System.exit(0);
}

  @Override
  public void windowDeactivated(WindowEvent arg0) {}

  @Override
  public void windowDeiconified(WindowEvent arg0) {}

  @Override
  public void windowIconified(WindowEvent arg0) {}

  @Override
  public void windowOpened(WindowEvent arg0) {}

  @Override
  public void actionPerformed(ActionEvent arg0) {
    System.exit(0);
  }
}
