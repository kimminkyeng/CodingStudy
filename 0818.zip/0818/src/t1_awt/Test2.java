package t1_awt;

import java.awt.Frame;

public class Test2 extends Frame{
  
  public Test2() { //자기자신을 생성.
    super("Frame Test2");
    
    setVisible(true);
    setSize(300, 300);
  }
  
  public static void main(String[] args) {
    new Test2(); //7번줄 생성자 호출.
  }
}
