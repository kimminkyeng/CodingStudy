package t1_awt;

import java.awt.Frame;

public class Test1 {
  public static void main(String[] args) {
    Frame f = new Frame();
    
    f.setVisible(true);
    f.setTitle("Frame Test");
    f.setSize(300, 300);
  }
}
