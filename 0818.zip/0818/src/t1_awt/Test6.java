package t1_awt;

import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

//FlowLayout 연습
public class Test6 extends Frame implements WindowListener, ActionListener {
  public Test6() {  
    super("윈도우 이벤트 연습");
    
    setLayout(new FlowLayout());
    setVisible(true);
    setBounds(300, 250, 300, 300);
    
    Button btn1 = new Button("버튼1");
    Button btn2 = new Button("버튼2");
    Button btn3 = new Button("종료버튼");
    Button btn4 = new Button("버튼4");
    Button btn5 = new Button("버튼5");
    
    add(btn1);
    add(btn2);
    add(btn3);
    add(btn4);
    add(btn5);
    
    Label lbl1 = new Label("제목1");
    Label lbl2 = new Label("제목2");
    Label lbl3 = new Label("제목3");
    Label lbl4 = new Label("제목4");
    Label lbl5 = new Label("제목5");
    Label lbl6 = new Label("제목6");
    Label lbl7 = new Label("제목7");
    Label lbl8 = new Label("제목8");
    
    add(lbl1);
    add(lbl2);
    add(lbl3);
    add(lbl4);
    add(lbl5);
    add(lbl6);
    add(lbl7);
    add(lbl8);
    
    btn3.addActionListener(this); //btn3 버튼은 종료버튼.
    addWindowListener(this);
  }
  public static void main(String[] args) {
    new Test6();
  }

  @Override
  public void windowActivated(WindowEvent e) {
  }

  @Override
  public void windowClosed(WindowEvent e) {
  }

  @Override
  public void windowClosing(WindowEvent e) {
    System.exit(0);
    
  }

  @Override
  public void windowDeactivated(WindowEvent e) {
  }

  @Override
  public void windowDeiconified(WindowEvent e) {
  }

  @Override
  public void windowIconified(WindowEvent e) {
  }

  @Override
  public void windowOpened(WindowEvent e) {
  }
  @Override
  public void actionPerformed(ActionEvent e) {
    System.exit(0);
  }

}
