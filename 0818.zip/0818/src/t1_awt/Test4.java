package t1_awt;

import java.awt.Frame;
import java.awt.Label;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class Test4 extends Frame implements WindowListener {
  public Test4() {
    super("WindowEvent Test");
    
    setVisible(true);  //윈도우 창(Frame) 보여주기
    //setSize(300, 300); //Frame 크기조절(가로,세로)(단점은 크기는 줄 수 있으나, 위치는 설정을 못함.)
    setBounds(300, 250, 300, 300); //Frame 위치와 크기(x,y,width,height)
    
    Label lbl1 = new Label("레이블테스트!!!!");
    
    this.add(lbl1);
    
    addWindowListener(this);
  }
  
  public static void main(String[] args) {
    new Test4();
  }
  
  @Override
  public void windowActivated(WindowEvent e) {}
  
  @Override
  public void windowClosed(WindowEvent e) {}
  
  @Override
  public void windowClosing(WindowEvent e) {
    System.exit(0);
  }
  
  @Override
  public void windowDeactivated(WindowEvent e) {}
  
  @Override
  public void windowDeiconified(WindowEvent e) {}
  
  @Override
  public void windowIconified(WindowEvent e) {}
  
  @Override
  public void windowOpened(WindowEvent e) {}
}
