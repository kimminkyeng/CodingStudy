package t1_awt;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

// BorderLayout 연습
public class Test7 extends Frame implements WindowListener, ActionListener {
  public Test7() {  
    super("윈도우 이벤트 연습(Test7)");
    
    setLayout(new BorderLayout());
    setVisible(true);
    setBounds(300, 250, 300, 300);
    
    Button btn1 = new Button("북쪽");
    Button btn2 = new Button("남쪽");
    Button btn3 = new Button("서쪽");
    Button btn4 = new Button("동쪽");
    Button btn5 = new Button("중앙(종료)");
    
    add(btn1, "North");
    add(btn2, "South");
    add(btn3, "West");
    add(btn4, "East");
    add(btn5, "Center");
    
    
    
    btn5.addActionListener(this); //btn5 중앙버튼은 종료버튼.
    addWindowListener(this);
  }
  public static void main(String[] args) {
    new Test7();
  }

  @Override
  public void windowActivated(WindowEvent e) {
  }

  @Override
  public void windowClosed(WindowEvent e) {
  }

  @Override
  public void windowClosing(WindowEvent e) {
    System.exit(0);
    
  }

  @Override
  public void windowDeactivated(WindowEvent e) {
  }

  @Override
  public void windowDeiconified(WindowEvent e) {
  }

  @Override
  public void windowIconified(WindowEvent e) {
  }

  @Override
  public void windowOpened(WindowEvent e) {
  }
  @Override
  public void actionPerformed(ActionEvent e) {
    System.exit(0);
  }

}
